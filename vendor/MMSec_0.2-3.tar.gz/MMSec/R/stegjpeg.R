# 08/2002 by Rainer B�hme <rb-stego@reflex-studio.de>
# 11/2004 extended by Nils Moh (save.jpg.dctmap)

load.jpg <- function(fname,dct=FALSE,dequantize=FALSE,fancy.upsampling=TRUE){
  if (dct) {
    res<-.Call("jpeg_read_coeff",fname,dequantize)
  }
  else {
    res<-.Call("jpeg_read_rgb",fname,fancy.upsampling)
  }
  res
}

save.jpg <- function(map,...){
  UseMethod("save.jpg")
}

save.jpg.rgbmap <- function(map,
                            fname=map$name,
			    quality=NULL,
			    overwrite=FALSE,
			    dct.method=c("slow","fast","float"))
{ 

  if (any(is.null(map$red),
          is.null(map$green),
	  is.null(map$blue))) stop("one or more components missing")
  
  d <- matrix(c(dim(map$red),dim(map$green),dim(map$blue),rep(0,6)),nrow=2)
  if (!all(d[,1]==d[,2],d[,1]==d[,3])) stop("components' dimensions do not match")
  
  .Call("jpeg_write_rgb_dct",map,fname,
  	quality,overwrite,which(match.arg(dct.method)==c("slow","fast","float")),FALSE)
  invisible(TRUE)
}

save.jpg.greymap <- function(map,
                             fname=map$name,
			     quality=NULL,
			     overwrite=FALSE,
			     dct.method=c("slow","fast","float"))
{ 

  if (is.null(map$grey)) stop("grey component missing")
  
  #d <- matrix(c(dim(map$red),dim(map$green),dim(map$blue),rep(0,6)),nrow=2)
  #if (!all(d[,1]==d[,2],d[,1]==d[,3])) stop("components' dimensions do not match")
  
  
  
  .Call("jpeg_write_rgb_dct",map,fname,
  	quality,overwrite,which(match.arg(dct.method)==c("slow","fast","float")),TRUE)
  invisible(TRUE)
}








save.jpg.dctmap <- function(map,
                            fname=map$name,
                            overwrite=FALSE)
{ 
 if(is.null(map$spatial.dim))stop("spatial.dim component is missing")
 if(!is.numeric(map$spatial.dim))stop("spatial.dim component is not a numeric vector")
 if(!is.integer(map$spatial.dim))
 {
  cat("WARNING: spatial.dim component is not integer, casting.. \n")
  map$width <- as.integer(map$width)
  #CAUTION: as.integer deletes names of components!!!
 }

#now looking at the picture data
 if(is.null(map$Y))stop("Y component is missing")
 if(!is.numeric(map$Y))stop("Y component is not a numeric vector")
 if(!is.integer(map$Y))
 {
  cat("WARNING: Y component is not integer, casting.. \n")
  dimY <- dim(map$Y)    
  map$Y <- as.integer(map$Y)
  map$Y <- array(map$Y,dimY)  #forces original 4-dimensional structure
 }

#Caution: grey dctmaps do not contain map$Cr
 if(!is.null(map$Cr))    #   => color jpeg 
   {
   isgrey <- FALSE
   if(!is.numeric(map$Cr))stop("Cr component is not a numeric vector")
   if(!is.integer(map$Cr))
     {
     cat("WARNING: Cr component is not integer, casting.. \n")
     dimCr <- dim(map$Cr)    
     map$Cr <- as.integer(map$Cr)
     map$Cr <- array(map$Cr,dimCr) #forces 4D structure
    }

  #look at map$Cb of color jpeg
    if(is.null(map$Cb))stop("Cb component is missing")
    if(!is.numeric(map$Cb))stop("Cb component is not a numeric vector")
    if(!is.integer(map$Cb))
      {
      cat("WARNING: Cb component is not integer, casting.. \n")
      dimCb <- dim(map$Cb)    
      map$Cb <- as.integer(map$Cb)
      map$Cb <- array(map$Cb,dimCb) #forces 4D structure
      }
    } #end color jpeg
 else
 {
 isgrey <- TRUE
 #Cr and Cb are ignored, because no code uses them in grey pictures
 }

# name dctmap overwrite isgrey 
  .Call("write_jpeg_dct", fname, map,overwrite,isgrey)

  invisible(TRUE) #not printed return value 
} # end of save.jpg.dctmap







print.dctmap <- function(map,...){
  cat("Components of DCT map:\n")
  if (!is.null(map$Y)) {
    cat("Y  : width=",dim(map$Y)[3]," height=",dim(map$Y)[4],
        "  ",(sum(map$Y==0)/length(map$Y))*100,"% zeros\n",sep="");
  }
  if (!is.null(map$Cr)) {
     cat("Cr : width=",dim(map$Cr)[3]," height=",dim(map$Cr)[4],
        "  ",(sum(map$Cr==0)/length(map$Cr))*100,"% zeros\n",sep="");
  }
  if (!is.null(map$Cb)) {
     cat("Cb : width=",dim(map$Cb)[3]," height=",dim(map$Cb)[4],
        "  ",(sum(map$Cb==0)/length(map$Cb))*100,"% zeros\n",sep="");
  }
  if (!is.null(map$spatial.dim)) {
     cat("Image width : ",map$spatial.dim[1],"\n",
         "Image height: ",map$spatial.dim[2],
         "\n",sep="");
  }
}

dcthist <- function(h,span=c(-8,8),
                    xlab="DCT coefficient values",ylab="Frequency",main="",
                    add=FALSE,...){
  t<-table(h)
  r<-as.numeric(names(t))
  x<-r[(r>=span[1])&(r<=span[2])]
  y<-t[(r>=span[1])&(r<=span[2])]
  if (add)
    lines(x=x,y=y,...)
  else
    plot(x,y,type="l",xlab=xlab,ylab=ylab,main=main,...)
}

hist.dctmap <- function(map,
                        cx=1:8,cy=cx,
                        breaks=-8,
                        xlab="",ylab="",
                        comp=c("Y","Cr","Cb"),add=FALSE,...){
  comp <- match.arg(comp)
  oldpar <- par(no.readonly = TRUE)
  if (!add) plot.new()
  if ((length(cx)>1)||(length(cy)>1))
    par(mfrow=c(length(cy),length(cx)),mar=c(1.9,2,1.6,0)+.1)
  h<-as.vector(map[[comp]][cx,cy,,])
  r<-range(h)
  if ((length(breaks)<2)&(breaks>0)) breaks<-seq(r[1],r[2]+1,length=breaks)
  for (x in 1:length(cx))
    for (y in 1:length(cy)) {
      par(mfg=c(y,x))
      if (length(breaks)<2) {
        dcthist(map[[comp]][cx[x],cy[y],,],
                span=c(breaks,-breaks),
                xlab=xlab,ylab=ylab,
                main=paste("(",cx[x],",",cy[y],")",sep=""),
                add=FALSE,...)
      }
      else
        hist(map[[comp]][cx[x],cy[y],,],
             breaks=breaks,
             xlab=xlab,ylab=ylab,
             main=paste("(",cx[x],",",cy[y],")",sep=""),...)
    }
  par(oldpar) 
}