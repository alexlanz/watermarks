 # by Nils Moh
# this file contains validity tests for datastructures to be passed
# to C functions to avoid duplicating code in gif and jpeg and png and ...
# formerly known as maptypes.R

#return values: erg$number==0    map is ok 
#                           1    unknown, not even a map? 
#                           2    class attrib is correct, but errors in structure

# valid.indexmap accepts an indexmap
# and returns a list with valid (bool) and text (character)
# tests palette, map ,red green blue and length of pal components


##############################################################################
## test for correct greymap:  (grey)
##############################################################################

valid.greymap <- function(imap)
{

#if(FALSE) {
#cat(" ")
#cat(" ")
#}


erg <- c()
att <- attr(imap,"class")

erg$number <- 1

if (is.null(att))
  {erg$valid <- FALSE;
   erg$text  <- "invalid greymap: 'class' attribute missing";
   return(erg);
  }

if (att != "greymap")
  {erg$valid <- FALSE;
   erg$text  <- "invalid greymap: The class attribute has to be 'greymap'";
   return(erg);
  }


erg$number <- 2

if (is.null(imap$grey))
  {erg$valid <- FALSE;
   erg$text  <- "invalid greymap: 'grey' component is missing";
   return(erg);
  }

if (!is.numeric(imap$grey))
  {erg$valid <- FALSE;
   erg$text  <- "invalid greymap: 'grey' component not numeric";
   return(erg);
  }

if (!is.matrix(imap$grey))
  {erg$valid <- FALSE;
   erg$text  <- "invalid greymap: 'grey' component not a matrix";
   return(erg);
  }




#everything ok:

erg$number <- 0
erg$valid <- TRUE
erg$text  <- "valid greymap"
return (erg)

}
#############################################################################
####red green blue
############################################################################

valid.rgbmap <- function(imap)
{

if(FALSE) {
cat(" ")
cat(" ")
}




erg <- c()
att <- attr(imap,"class")

if (is.null(att))
  {erg$number <- 1;
   erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: 'class' attribute missing";
   return(erg);
  }

if (att != "rgbmap")
  {erg$number <- 1;
   erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: The class attribute has to be 'rgbmap'";
   return(erg);
  }
####### color components
erg$number <- 2

if (is.null(imap$red))
  {erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: 'red' component is missing";
   return(erg);
  }

if (is.null(imap$green))
  {erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: 'green' component is missing";
   return(erg);
  }

if (is.null(imap$blue))
  {erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: 'red' component is missing";
   return(erg);
  }
 ######### is.numeric tests
if ((!is.numeric(imap$red  ))||(!is.matrix(imap$red)))
  {erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: 'red' component is not a numeric matrix";
   return(erg);
  }

if ((!is.numeric(imap$green))||(!is.matrix(imap$green)))
  {erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: 'green' component is not numeric matrix";
   return(erg);
  }

if ((!is.numeric(imap$blue ))||(!is.matrix(imap$blue)))
  {erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: 'blue' component is not numeric matrix";
   return(erg);
  }

# now we have numeric matrices, only missing test is size

d <- matrix(c(dim(imap$red),dim(imap$green),dim(imap$blue),rep(0,6)),nrow=2)
if(!all(d[,1]==d[,2],d[,2]==d[,3],d[,1]==d[,3]))
  {erg$valid <- FALSE;
   erg$text  <- "invalid rgbmap: components dimensions do not match";
   return(erg);
  }

#everything ok:
erg$valid <- TRUE
erg$number <- 0
erg$text  <- "valid rgbmap"
return (erg)

}
