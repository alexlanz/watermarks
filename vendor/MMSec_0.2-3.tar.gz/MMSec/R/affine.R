"resize.2d" <-
function (M, size=NULL, omega=NULL, interpolate = c("bspline","bicubic","sinc"), splineDegree = 1, support = 9, sigma = 0) {
    
	if ((!is.numeric(M)) || (!is.numeric(sigma))) {
        stop("only numeric arguments allowed")
    }
	
	if (is.null(omega)){
		if (length(size) != 2)
			stop("specify size in 2 dimensions")
	
    	size <- as.integer(size)
    	method <- match.arg(interpolate)
    	if (method == "sinc")
        	res <- .Call("scale_sinc", M, as.integer(size), as.integer(support))
    	if (method == "bicubic")
    		res <- .Call("scale_bicubic", M, as.integer(size), sigma)
    	if (method == "bspline") {
        	if (splineDegree > 1) {
          		if (splineDegree <= 9)
          			coeff <- .Call("bspline_coefficients", M, as.integer(splineDegree))
          		else
            		stop("B-spline interpolation with degree > 9 not implemented ...")
        		}
        	else
        		coeff <- M
        	res <- .Call("scale_b", M, coeff, as.integer(size), as.integer(splineDegree), sigma)
    	}
    }
    else {
    	method <- match.arg(interpolate)
    	if (method!="bspline")
    		warning("B-spline interpolation")
    	if (splineDegree > 1) {
          	if (splineDegree <= 9)
          		coeff <- .Call("bspline_coefficients", M, as.integer(splineDegree))
          	else
            	stop("B-spline interpolation with degree > 9 not implemented ...")
        	}
        else
        	coeff <- M
        res <- .Call("scale_bw", M, coeff, omega, as.integer(splineDegree), sigma)
        if (omega>1){
        	d1<-floor(dim(M)[1]/omega)
        	d2<-floor(dim(M)[2]/omega)
        	res<-res[1:d1,1:d2]
        }
    }
    
    res
}

"rotate.2d" <-
function (M, angle.rad, interpolate = "bspline", splineDegree=1) {

    if ((!is.numeric(M)) || (!is.numeric(angle.rad))) {
        stop("only numeric arguments allowed")
    }
    	
	if (splineDegree > 1)
	{
		if (splineDegree <= 9)
			coeff <- .Call("bspline_coefficients", M, splineDegree)
		else 
			stop("B-spline interpolation with degree > 9 not implemented ...")
	}
	else
		coeff <- M
	
	res <- .Call("rotate", M, coeff, angle.rad, as.integer(splineDegree))
}
