"generic.filter"<-function(filter,M,windowsize,mirror,...){
		w<-as.integer(windowsize)
		if (!mirror){
  		res<-.Call(filter,M,w,...)
  		}
    else{
  		e<-w%/%2
  		if (length(e)==1) e<-rep(e,2)
  		M<-mirror(M,e)
  		d<-dim(M)
      res<-.Call(filter,M,w,...)[(e[1]+1):(d[1]-e[1]),(e[2]+1):(d[2]-e[2])]
    }
}



"lin.filter.2d" <- function(M,windowsize=c(3,3),coefficients,mirror=TRUE){
	if ((!is.numeric(M)) || (!is.numeric(windowsize)) || (!is.numeric(coefficients)))
		cat("only numeric arguments allowed")
	else
    generic.filter("gen_filter",M,windowsize,mirror,coefficients)
}


"median.2d" <- function(M,windowsize=3,mirror=TRUE){
	if ((!is.numeric(M)) || (!is.numeric(windowsize)))
		cat("only numeric arguments allowed")
	else
    generic.filter("median_filter",M,windowsize,mirror)
}

"order.2d" <- function(M,order=c("max","min","median"),windowsize=3,mirror=TRUE){
	if ((!is.numeric(M)) || (!is.numeric(windowsize)))
		cat("only numeric arguments allowed")
	else { 
		o<-match.arg(order)
		if (o == "max") {
			generic.filter("max_filter",M,windowsize,mirror)
			}
		else {
			if (o == "min") O<-1;
			if (o == "median") O<-(windowsize^2+1)/2
			generic.filter("order_filter",M,windowsize,mirror,as.integer(O))
			}
		}
}

"multi.median.2d" <- function(M,windowsize=5,mode=c("bidirectional","unidirectional"),mirror=TRUE){
	
	if ((!is.numeric(M)) || (!is.numeric(windowsize)))
		cat("only numeric arguments allowed")
	else{
		m<-match.arg(mode)
		if (m == "bidirectional")
			generic.filter("m_median_filter",M,windowsize,mirror,as.integer(1))
		else
			generic.filter("m_median_filter",M,windowsize,mirror,as.integer(0))
	}
}

"binomial.2d" <- function(M,windowsize=3,mirror=TRUE){
	if ((!is.numeric(M)) || (!is.numeric(windowsize)))
		cat("only numeric arguments allowed")
	else
		generic.filter("binomial_filter2",M,windowsize,mirror)
}


"average.2d" <- function(M,windowsize=3,mirror=TRUE){

	if ((!is.numeric(M)) || (!is.numeric(windowsize)))
		cat("only numeric arguments allowed")
	else
    res<-generic.filter("average_filter",M,windowsize,mirror)
}

"sobel.2d" <- function(M,direction=c("vertical","horizontal")){
	if (!is.numeric(M))
		cat("only numeric arguments allowed")
	else{
		dir<-match.arg(direction)
		if (dir == "vertical")
			res<-.Call("sobel_filter",M,as.integer(1))
		else
			res<-.Call("sobel_filter",M,as.integer(2))
	}
}

"local.var.2d" <- function(M,windowsize=3,mirror=TRUE){
	if ((!is.numeric(M)) || (!is.numeric(windowsize)))
		cat("only numeric arguments allowed")
	else
		generic.filter("local_variance",M,windowsize,mirror)
}