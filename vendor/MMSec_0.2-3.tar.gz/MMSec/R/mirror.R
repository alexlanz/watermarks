"mirror" <-
function (M, expand = c(1, 1)) 
{
    lr <- expand[1]
    lc <- expand[2]
    cols <- ncol(M)
    rows <- nrow(M)
    # new number of rows and cols
    cols.n <- cols + 2 * lc
    rows.n <- rows + 2 * lr
    ir <- rows.n - lr + 1
    ic <- cols.n - lc + 1
    ## expanding ##
    if (lr<1 && lc<1) 
    	# no expanding
    	res <- M
    else {
    	res <- matrix(0, rows.n, cols.n)
    	if (lr<1) {
    		# column expanding
    		res[, -c(1:lc, ic:cols.n)] <- M
    		res[, lc:1] <- res[, (lc + 2):(2 * lc + 1)]
    		res[, cols.n:ic] <- res[, (ic - 1 - lc):(ic - 2)]
    		}
    	else {
    		if (lc<1) {
    			# row expanding
    			res[-c(1:lr, ir:rows.n),] <- M
    			res[lr:1, ] <- res[(lr + 2):(2 * lr + 1), ]
		    	res[rows.n:ir, ] <- res[(ir - 1 - lr):(ir - 2), ]
    			}
    		else {
    			# row and column expanding
    			res[-c(1:lr, ir:rows.n), -c(1:lc, ic:cols.n)] <- M
		    	res[lr:1, ] <- res[(lr + 2):(2 * lr + 1), ]
    			res[rows.n:ir, ] <- res[(ir - 1 - lr):(ir - 2), ]
		    	res[, lc:1] <- res[, (lc + 2):(2 * lc + 1)]
    			res[, cols.n:ic] <- res[, (ic - 1 - lc):(ic - 2)]
    			}
    		}
    	}
    res
}
