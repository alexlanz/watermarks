"int.hist"<-function(x,scale=255,range=c(0,255),...){
	hist(x*scale,breaks=(range[1]-0.5):(range[2]+0.5),...)
}

"int.histA"<-function(x,scale=1,range=NULL,...){
	if (is.null(range))
		range<-range(x*scale)
	hist(x*scale,breaks=(range[1]-0.5):(range[2]+0.5),...)
}