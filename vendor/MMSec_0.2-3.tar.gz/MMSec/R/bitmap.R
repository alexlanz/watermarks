# 05/2004 by Rainer B�hme <rb-stego@reflex-studio.de>

# ---------------------------------------------------
# Handling RGB Bitmaps
# Components:
# $red, $green, $blue: image channels (values 0 <= x <= 1)
# $name: optional original file name
# $tables: optional JPEG tables

plot.rgbmap <- function(map,xlab="",ylab="",main=map$name,...){
  dx <- dim(map$red)[2]
  dy <- dim(map$red)[1]
  col <- rgb(map$red,map$green,map$blue)
  image(x=0:dx,y=0:dy,
        z=t(matrix(1:(dx*dy),ncol=dx)),
        col=col,ylim=c(dy,0),xlim=c(0,dx),
        xlab=xlab,ylab=ylab,main=main,...)
}

print.rgbmap <- function(map,...){
  cat("Name    :",map$name,"\n")
  cat("Width   :",dim(map)[2],"\n")
  cat("Height  :",dim(map)[1],"\n")
  cat("Comment :",map$marker["COM"],"\n")
}


diff.rgbmap <- function(e1,e2,abs=TRUE,scale=1) {
  res <- e1
  if (abs){
    res$red <- abs(e1$red - e2$red)*scale
    res$green <- abs(e1$green - e2$green)*scale
    res$blue <- abs(e1$blue - e2$blue)*scale
  }
  else{
    res$red <- (e1$red - e2$red)*scale
    res$green <- (e1$green - e2$green)*scale
    res$blue <- (e1$blue - e2$blue)*scale
  }
  res
}

dim.rgbmap <- function(map) { dim(map$red) }

rgbdens <- function(map,main=map$name,xlab="Density",ylab="",...){
  dr<-density(map$red)
  dg<-density(map$green)
  db<-density(map$blue)
  plot(dr,type="l",col="red",
       ylim=range(c(dr$y,dg$y,db$y)),
       main=main,xlab=xlab,ylab=ylab,...)
  lines(dg,type="l",col="green")
  lines(db,type="l",col="blue")
}

# ---------------------------------------------------
# Handling Greyscale Bitmaps
# Components:
# $grey: image channel (values 0 <= x <= 1)
# $name: optional original file name
# $tables: optional JPEG tables

checkmap <- function(map)
{
  if (!is.matrix(map)) 
    stop ("map argument is not a matrix")
  
  if (min(map)<0)
    stop ("map argument contains negative values")

  if (!any( abs(map-as.integer(map)) > 0  ))
  	map <- map/255		# convert bytes to floats

  if (max(map)>1)
    stop ("map argument intensity values too high")
  
  map
}

greymap <- function(shades, ...)
{
  result <- list(grey=checkmap(shades), ...)
  class(result) <- "greymap"
  result
}

print.greymap <- function(map,...){
  cat("Name    :",map$name,"\n")
  cat("Width   :",dim(map)[2],"\n")
  cat("Height  :",dim(map)[1],"\n")
  cat("Comment :",map$marker["COM"],"\n")
}

plot.greymap <- function(map,xlab="",ylab="",main=map$name,...){
  dx <- dim(map$grey)[2]
  dy <- dim(map$grey)[1]
  col <- grey(map$grey)
  image(x=0:dx,y=0:dy,
        z=t(matrix(1:(dx*dy),ncol=dx)),
        col=col,ylim=c(dy,0),xlim=c(0,dx),
        xlab=xlab,ylab=ylab,main=main,...)
}

dim.greymap <- function(map) { dim(map$grey) }




# ---------------------------------------------------
# Conversion between different bitmap objects


as.matrix.greymap <- function(map){ map$grey }

as.matrix.rgbmap <- function(map,weights=c(0.299,0.587,0.114)){
  if (length(weights)!=3) stop("weights vector must have three elements")
  map$red*weights[1]+map$green*weights[2]+map$blue*weights[3]
}


as.rgbmap <- function (map, ...) UseMethod("as.rgbmap") 
as.greymap <- function (map, ...) UseMethod("as.greymap")

as.greymap.greymap <- function(map, ...) { map }
as.rgbmap.rgbmap <- function(map, ...) { map }

as.greymap.rgbmap <- function(map, weights=c(0.299,0.587,0.114))
{
  if (length(weights)!=3) stop("weights vector must have three elements")

  result <- list(grey=map$red*weights[1]+map$green*weights[2]+map$blue*weights[3])

  if (!is.null(map$name))
    result <- append(result,(list(name=map$name)))
 
  if (!is.null(map$tables))
    result <- append(result,(list(tables=list(luminance=map$tables$luminance))))
  
  class(result) <-"greymap"
  result
}

as.rgbmap.greymap <- function(map)
{
  result <- list (red=map$grey,
                  green=map$grey,
		  blue=map$grey)
  
  if (!is.null(map$name))
    result <- append(result,(list(name=map$name)))
 
  if (!is.null(map$tables))
    result <- append(result,(list(tables=
                            list(luminance=map$tables$luminance,
			         chrominance=map$tables$luminance))))
   
 class(result) <- "rgbmap"
 result
}
