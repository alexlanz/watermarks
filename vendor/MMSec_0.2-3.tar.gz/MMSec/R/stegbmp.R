# 11/2004 by Benjamin Scholz <Benjamin.Scholz@inf.tu-dresden.de>

load.bmp <- function(fname){
  .Call("bmp_read_rgb",fname)
}

save.bmp <- function(map,fname=map$name,overwrite=FALSE){

  if(!is.logical(overwrite)){stop("Overwrite has to be logical.")}
  if(!is.character(fname)){stop("Filename has to be character.")}
  if(is.null(map)){stop("Map component missing.")}

  if (class(map) == "indexmap") { index <- 1 }
  else { index <- 0 }
  
  .Call("bmp_write_rgb",map,fname,overwrite, index)
}
