#
# Qtab.R - Create JPEG quantisation tables similar to libjpeg
# (w) 2004 Rainer Boehme <rb-stego@reflex-studio.de>
#

qtab <- function(quality = 1, type = c("luminance","chrominance"), linear = FALSE, baseline = FALSE, empirical = FALSE)
{
  # check input parameters
  
  type <- match.arg(type)
  
  if (!linear)  # allow any scaling for linear quality
  {
    if (quality > 1) quality = quality / 100
    if ((quality > 1) | (quality <= 0))
    	  stop ("non-linear quality must be between 0 and 1")
  }

  # define base matrix (these values are given in the JPEG spec section K.1
  #                     also used in libjpeg, file jcparam.c )

  std.lum <- t(matrix(c( 16,  11,  10,  16,  24,  40,  51,  61,
    	                 12,  12,  14,  19,  26,  58,  60,  55,
                         14,  13,  16,  24,  40,  57,  69,  56,
                         14,  17,  22,  29,  51,  87,  80,  62,
                         18,  22,  37,  56,  68, 109, 103,  77,
                         24,  35,  55,  64,  81, 104, 113,  92,
                         49,  64,  78,  87, 103, 121, 120, 101,
                         72,  92,  95,  98, 112, 100, 103,  99 ),8))

  std.crm <- t(matrix(c( 17,  18,  24,  47,  99,  99,  99,  99,
    		         18,  21,  26,  66,  99,  99,  99,  99,
                         24,  26,  56,  99,  99,  99,  99,  99,
                         47,  66,  99,  99,  99,  99,  99,  99,
    		         99,  99,  99,  99,  99,  99,  99,  99,
    		         99,  99,  99,  99,  99,  99,  99,  99,
    	                 99,  99,  99,  99,  99,  99,  99,  99,
    		         99,  99,  99,  99,  99,  99,  99,  99 ),8))

  # scale to linear (make sure that rounding appears in exactly the same way as libjpeg does)

  if (!linear)
  {
    if (!empirical)
    {
  			# theoretical computation
      if (quality < .5)
        quality <- trunc(5000 / round(100 * quality)) 
      else
        quality <- (200 - 2 * round(100 * quality))
    }  
    else   	        # empirical mappings for libjpeg62b (measured on AMD Athlon with Debian Linux, Sep 2004)
    
    quality <- c(
       5000,2500,2500,1250,1000,1000, 714, 625, 625, 500, 454, 454, 384, 357, 357,
   	312, 294, 294, 263, 250, 250, 227, 217, 217, 200, 192, 185, 178, 178, 172,
  	166, 156, 151, 147, 147, 142, 138, 131, 128, 125, 125, 121, 119, 113, 111,
 	108, 108, 106, 104, 100,  98,  96,  94,  92,  90,  88,  88,  86,  84,  82,
 	 80,  78,  74,  72,  70,  68,  66,  64,  64,  62,  60,  58,  56,  54,  50,
 	 48,  46,  44,  42,  40,  38,  38,  36,  34,  32,  30,  28,  24,  22,  20,
 	 18,  16,  14,  14,  12,  10,   8,   6,   4,   0)[round(quality*100)]

  }
 
  # select appropriate base matrix 
  
  if (type=="chrominance")
  	m <- std.crm
  else
  	m <- std.lum

  # scale matrix

  m <- trunc((m * quality + 50)/100)
  
  # limit bounds
  
  m[m<1] <- 1
  if (baseline)
  	m[m>255] <- 255
  else
  	m[m>32767] <- 32767

  m
}

# Table-handling functions


# Define method stubs for virtual methods
#
tables <- function(obj) UseMethod("tables")
"tables<-" <- function(obj,value) UseMethod("tables<-")

tables.rgbmap <- function(obj) obj$tables
# returns tables of rgbmap object

tables.dctmap <- function(obj) obj$tables
# returns tables of dctmap object

"tables<-.rgbmap" <- function(obj,value) 
# sets tables for rgbmap objects
{
  if (is.list(value))
  {
    if (all(names(value)==c("luminance","chrominance")))
      obj$tables <- value
    else
     stop ("Scalar or tables structure required.")
  }
  else
    obj$tables <- list(luminance=qtab(value[1],type="lum"),
    		       chrominance=qtab(value[1],type="chrom"))
  obj
}

"tables<-.dctmap" <- function(obj,value) 
# sets tables for dctmap objects
{
  if (is.list(value))
  {
    if (all(names(value)==c("luminance","chrominance")))
      obj$tables <- value
    else
     stop ("Scalar or tables structure required.")
  }
  else
    obj$tables <- list(luminance=qtab(value[1],type="lum"),
    		       chrominance=qtab(value[1],type="chrom"))
  obj
}


# Some tests of qtab() with libjpeg

# create test set
# for (q in 1:100) save.jpg(j,paste("T-",q,".jpg",sep=""),q=q/100)

# verify ind. quality
# q<-50;t<-tables(load.jpg(paste("T-",q,".jpg",sep="")));print(t$l-qtab(q,ty="l"));print(t$c-qtab(q,ty="c"))
#
# vqual <- function(...)
# {
#   (sapply (2:100,function(q) {
#    t <- tables(load.jpg(paste("T-",q,".jpg",sep="")))
#     sum((t$l-qtab(q/100,ty="l",...))^2)
# }
#    ))
# }


# Find number of unique values per DCT mode for q in 1..100
# nu <- matrix(0,8,8)
# for (i in 1:8) for (j in 1:8)
# nu[i,j] <- length(unique(sapply(1:100,function(q){qtab(q/100)[i,j]})))


