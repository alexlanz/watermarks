"block" <-
function(M,dim.block=c(5,5),overlap=c(dim.block[1]-1,dim.block[2]-1),mirror=FALSE){
	
	l<-(dim.block-1)/2
	if (mirror)
    M<-mirror(M,l)
	d<-as.integer(dim.block)
	o<-as.integer(overlap)
	res<-.Call("block",M,d,o)

}