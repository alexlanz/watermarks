# 12/2003 by Rainer B�hme <rb-stego@reflex-studio.de>
#save.png by Nils Moh
load.png <- function(fname){
  .Call("png_read_rgb",fname)
}

save.png <- function(input,filename,overwrite=FALSE)
{ 

    vrgb   <- valid.rgbmap(input)
    vgrey  <- valid.greymap(input)
   
  if (!((vrgb$valid) || (vgrey$valid)))
  {
    errortext <- ""
    if (vindex$number==2)
     { errortext <- (vindex$text)}
    else if (vrgb$number==2) 
     { errortext <- (vrgb$text)}
    else if (vgrey$number==2) 
     { errortext <- (vgrey$text)} 
    else 
     { errortext <- ("class attrib missing") }
    
    stop (paste("\n Not a valid datastructure. \n ",errortext,sep=""))
  }



  res<-.Call ("makePNGglobal",input,filename,overwrite)

	invisible(TRUE); 
} 
 