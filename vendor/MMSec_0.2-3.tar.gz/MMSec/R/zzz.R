#.First.lib <- function(lib, pkg) {
#    library.dynam("MMSec", pkg, lib)
#} 
