/***************************************************************************
 *            getter.c
 *
 *  Copyright  2004  Benjamin Scholz
 *  Benjamin.Scholz@inf.tu-dresden.de
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 *  This code is inspired by the code from bmptopnm.c
 *
 *  Copyright (C) 1992 by David W. Sanderson.
 *
 *  Permission to use, copy, modify, and distribute this software and its
 *  documentation for any purpose and without fee is hereby granted,
 *  provided that the above copyright notice appear in all copies and
 *  that both that copyright notice and this permission notice appear
 *  in supporting documentation.  This software is provided "as is"
 *  without express or implied warranty.
 *
 */


#include <stdio.h>

void
putShort(short value, FILE * fp) {
	putc(value & 0x00FF, fp);
	putc((value & 0xFF00)>>8 , fp);
}

void
putLong(long value, FILE * fp) {
	putc(value & 0x000000FF, fp);
	putc((value & 0x0000FF00)>>8 , fp);
	putc((value & 0x00FF0000)>>16 , fp);
	putc((value & 0xFF000000)>>24 , fp);
}

char
getByte(FILE * fp) {
	int c;

	if ( (c = getc( fp )) == EOF )
        return -1;
	return c;
}

short
getShort(FILE * fp) {
	int c;
	short retval;

	if ( (c = getc( fp )) == EOF )
        return -1;
    retval = c & 0xff;
    if ( (c = getc( fp )) == EOF )
        return -1;
    retval |= ( c & 0xff ) << 8;
    return retval;
}

long
getLong(FILE * fp) {
    long c;
	long retval;

if ( (c = getc( fp )) == EOF )
        return -1;
    retval = c & 0xff;
	if ( (c = getc( fp )) == EOF )
        return -1;
    retval |= ( c & 0xff ) << 8;
    if ( (c = getc( fp )) == EOF )
        return -1;
    retval |= ( c & 0xff ) << 16;
    if ( (c = getc( fp )) == EOF )
        return -1;
    retval |= ( c & 0xff ) << 24;
    return retval;
}
