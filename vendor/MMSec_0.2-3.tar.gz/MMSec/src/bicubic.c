#include <R.h>
#include <Rmath.h>
#include <math.h>
#include <Rinternals.h>

#include	<stddef.h>
#include	<stdio.h>
#include	<stdlib.h>


double BicubicInterpolatedValue
				(
					SEXP	M,			/* input array */
					long	Width,		/* width of the image */
					long	Height,		/* height of the image */
					double	x,			/* x coordinate where to interpolate */
					double	y			/* y coordinate where to interpolate */
				)

{ /* begin InterpolatedValue */

	double	xWeight[4], yWeight[4];
	double	interpolated;
	double	w;
	long	xIndex[4], yIndex[4];
	long	Width2 = 2L * Width - 2L, Height2 = 2L * Height - 2L;
	long	i, j, k;
	long	a,b,c;

	/* compute the interpolation indexes */
	i = (long)floor(x) - 1L;
	j = (long)floor(y) - 1L;
	for (k = 0L; k <= 3; k++) {
		xIndex[k] = i++;
		yIndex[k] = j++;
	}
	

	/* compute the interpolation weights */
	/* x */
	w = x - (double)xIndex[0]; // w > 0
	xWeight[0] = -0.5*w*w*w + 2.5*w*w - 4*w + 2;
	w = w-1; // w >= 0
	xWeight[1] =  1.5*w*w*w - 2.5*w*w + 1;
	w = w-1; // w < 0
	xWeight[2] = -1.5*w*w*w - 2.5*w*w + 1;
	w = w-1; // w < 0
	xWeight[3] = 0.5*w*w*w + 2.5*w*w + 4*w + 2;

	/* y */
	w = y - (double)yIndex[0];
	yWeight[0] = -0.5*w*w*w + 2.5*w*w - 4*w + 2;
	w = w-1;
	yWeight[1] =  1.5*w*w*w - 2.5*w*w + 1;
	w = w-1;
	yWeight[2] = -1.5*w*w*w - 2.5*w*w + 1;
	w = w-1;
	yWeight[3] =  0.5*w*w*w + 2.5*w*w + 4*w + 2;


	/* apply the mirror boundary conditions */
	for (k = 0L; k <= 3; k++) {
		xIndex[k] = (Width == 1L) ? (0L) : ((xIndex[k] < 0L) ?
			(-xIndex[k] - Width2 * ((-xIndex[k]) / Width2))
			: (xIndex[k] - Width2 * (xIndex[k] / Width2)));
		if (Width <= xIndex[k]) {
			xIndex[k] = Width2 - xIndex[k];
		}
		yIndex[k] = (Height == 1L) ? (0L) : ((yIndex[k] < 0L) ?
			(-yIndex[k] - Height2 * ((-yIndex[k]) / Height2))
			: (yIndex[k] - Height2 * (yIndex[k] / Height2)));
		if (Height <= yIndex[k]) {
			yIndex[k] = Height2 - yIndex[k];
		}
	}

	/* perform interpolation */
	interpolated = 0.0;
	for (j = 0L; j <= 3; j++) {
		w = 0.0;
		for (i = 0L; i <= 3; i++) {
			w += xWeight[i] * REAL(M)[xIndex[i]*Height + yIndex[j]]; 
		}
		interpolated += yWeight[j] * w;
	}

	return(interpolated);
} /* end InterpolatedValue */



/******
Image resizing with Keys bicubic interpolation (a = -0.5)

*************

Tamper Hiding: Defeating Image Forensics
Matthias Kirchner, Rainer Böhme.
Proceedings of the 9th Information Hiding Workshop, 2007.

Interpolation Revisited.
Philippe Thévenaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.

*************

M		input matrix
dim		dimension of the resized image
r		strength of geometric distortion (standard deviation)

******/
SEXP scale_bicubic(SEXP M, SEXP dim, SEXP r){

	SEXP res;
	int h, w, N_h, N_w, i, j;
	int P = 0;
	double z,x1,y1,rand;
	
	rand = REAL(r)[0];
	
	h = INTEGER(dim)[0];
	w = INTEGER(dim)[1];
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	
	PROTECT(res = allocMatrix(REALSXP, h, w));
	P++;
	
	// interpolation positions in x and y direction
	double x[w], y[h];
	GetRNGstate();
		
	z = ((double)N_w-1)/(w-1);
	for (i = 0; i < w; i++){
		x[i] = z*i;
		}
	z = ((double)N_h-1)/(h-1);
	for (i = 0; i < h; i++){
		y[i] = z*i;
		}
	
	// perform interpolation
	for (i = 0; i < w; i++){
		for (j = 0; j < h; j++){
			
			x1 = x[i] + rnorm(0,rand);
			y1 = y[j] + rnorm(0,rand);
			REAL(res)[i*h + j] = BicubicInterpolatedValue(M, N_w, N_h, x1, y1);
		 } 
	}
	
	UNPROTECT(P);
	PutRNGstate();
	
	return(res);
}


/******
Image resizing with Keys bicubic interpolation (a = -0.5)
Signal adaptive geometric distortion to hide traces of resampling

*************

Tamper Hiding: Defeating Image Forensics
Matthias Kirchner, Rainer Böhme.
Proceedings of the 9th Information Hiding Workshop, 2007.

Interpolation Revisited.
Philippe Thévenaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.

*************

M		input matrix
dim		dimension of the resized image
r		strength of geometric distortion (standard deviation)
sobelh	result of a horizontal edge detector (applied to the already scaled image)
sobelv	result of a vertical edge detector (applied to the already scaled image)

******/
SEXP scale_bicubic2(SEXP M, SEXP dim, SEXP r, SEXP sobelh, SEXP sobelv){

	SEXP res;
	
	int h, w, N_h, N_w, i, j;
	int P = 0;
	
	double z,x1,y1,rand;
	
	rand = REAL(r)[0];
	
	h = INTEGER(dim)[0];
	w = INTEGER(dim)[1];
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	PROTECT(res = allocMatrix(REALSXP, h, w));
	P++;
	
	// interpolation positions in x and y direction
	double x[w], y[h];
	GetRNGstate();
		
	z = ((double)N_w-1)/(w-1);
	for (i = 0; i < w; i++){
		x[i] = z*i;
		}
	z = ((double)N_h-1)/(h-1);
	for (i = 0; i < h; i++){
		y[i] = z*i;
		}
	
	// perform interpolation
	for (i = 0; i < w; i++){
		for (j = 0; j < h; j++){

			x1 = x[i] + (1-REAL(sobelv)[i*h + j]/255)*rnorm(0,rand);
			y1 = y[j] + (1-REAL(sobelh)[i*h + j]/255)*rnorm(0,rand);
			
			REAL(res)[i*h + j] = BicubicInterpolatedValue(M, N_w, N_h, x1, y1);
		 } 
	}
	
	UNPROTECT(P);
	PutRNGstate();
	return(res);
}

