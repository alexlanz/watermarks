// (w) 08/2002 Rainer Böhme <rb@reflex-studio.de>
// (w) 11/2004 Nils Moh
// (c) DRESDEN UNIVERSITY OF TECHNOLOGY

#include <R.h>
#include <Rinternals.h>
#define STEGANALRPACKAGE 1
#include <jpeglib.h>
#include <jerror.h>
#include "labels.h"
#include "stegtools.h"

#define MAX_MARKER 	20
#define MAX_JCOMPONENTS  3

#define JOB_READ_PIXEL		0x01
#define JOB_MARKERS     	0x02
#define JOB_READ_COEFF  	0x10
#define JOB_DEQUANTIZE  	0x20
#define JOB_FANCYUPSAMPLING 	0x40

// keep compatibility with libjpeg prior to V6a

#if JPEG_LIB_VERSION < 61
#define JPEG_ZIGZAG(k) jpeg_zigzag_order[k]

const int jpeg_zigzag_order[DCTSIZE2] = {
   0,  1,  5,  6, 14, 15, 27, 28,
   2,  4,  7, 13, 16, 26, 29, 42,
   3,  8, 12, 17, 25, 30, 41, 43,
   9, 11, 18, 24, 31, 40, 44, 53,
  10, 19, 23, 32, 39, 45, 52, 54,
  20, 22, 33, 38, 46, 51, 55, 60,
  21, 34, 37, 47, 50, 56, 59, 61,
  35, 36, 48, 49, 57, 58, 62, 63
}

#else
#define JPEG_ZIGZAG(k) k
#endif // old libjpeg

//read picture data is stored in the jpeg global structure
//by jpeg_do_read etc.
//and then used by jpeg_read_coeff etc. to build R
//data structures
//writing is similar

struct
{ unsigned char * data;                //pointer to picture data

  int dx;                              //picture width
  int dy;                              //picture height
  unsigned char * mark[MAX_MARKER];
  unsigned char * mname[MAX_MARKER];
  int mpos;

  int * coeff[MAX_JCOMPONENTS];         // DCT coefficients
  int bdx[MAX_JCOMPONENTS]; 		// width_in_blocks
  int bdy[MAX_JCOMPONENTS]; 		// height_in_blocks
  int cpos;

  int tables[2][DCTSIZE2];		// quant tables for slot 0 (luminance) and 1 (chrominance)
  int n_tables;				// 1 = only luminance, 2 = both

} jpeg_global;

// JPEG Libary Handler

unsigned int jpeg_getc (j_decompress_ptr cinfo)
/* Read next byte */
{
  struct jpeg_source_mgr * datasrc = cinfo->src;

  if (datasrc->bytes_in_buffer == 0) {
    if (! (*datasrc->fill_input_buffer) (cinfo))
      ERREXIT(cinfo, JERR_CANT_SUSPEND);
  }
  datasrc->bytes_in_buffer--;
  return GETJOCTET(*datasrc->next_input_byte++);
}

//writes markers from jpeg_global
boolean jpeg_handle_marker (j_decompress_ptr cinfo)
{
  INT32 length;
  unsigned char * p = NULL;

  length = jpeg_getc(cinfo) << 8;
  length += jpeg_getc(cinfo);
  length -= 2;			/* discount the length word itself */

  if (jpeg_global.mpos<MAX_MARKER) {
    char mname[20];
    p = jpeg_global.mark[jpeg_global.mpos] = R_alloc(length+1,1);
    if (cinfo->unread_marker == JPEG_COM)
      sprintf(mname,"COM");
    else
      sprintf(mname,"APP%d",cinfo->unread_marker - JPEG_APP0);
    jpeg_global.mname[jpeg_global.mpos] = R_alloc(strlen(mname)+1,1);
    strcpy(jpeg_global.mname[jpeg_global.mpos],mname);
  }
  else
    if (jpeg_global.mpos==MAX_MARKER) warning("too many markers - skipped marker in jpeg file");

  while (--length >= 0) {
    if (p) {
      *(p) = jpeg_getc(cinfo);
      if (!p[0]) p[0] = 0x20;
      p++;
    }
    else jpeg_getc(cinfo);
  }
  p[0] = 0; jpeg_global.mpos++;

  return TRUE;
}
//////////////////////////////////////////////////////
// "low level" read function
// -gets job constants and does the given tasks
// -writes data to jpeg_global
// -opens file
///////////////////////////////////////////////////////
int jpeg_do_read(char * fname,int read_job)
{
  FILE * f;
  int y,i, slot;
  int bytesperpixel; //number of bytes needed for one pixel
  int isgrey;        //is this a greyscale or rgb image
  unsigned char * sl;                    //bytestring that will become a copy of
                                         //jpeg_global.data

  struct jpeg_decompress_struct cinfo;   //private to jpeg_do_read !!!
  struct jpeg_error_mgr jerr;            //private to jpeg_do_read !!!

  if (!(f = fopen(fname, "rb")))
    error("unable to open file %s",fname);

  memset(&cinfo,0x00,sizeof(cinfo));     //write zeros into these data structures
  memset(&jerr,0x00,sizeof(jerr));

  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_decompress(&cinfo);
  jpeg_stdio_src(&cinfo,f);

  // insert marker handler (except APP0 and APP14)

  if (read_job & JOB_MARKERS) {
    jpeg_global.mpos = 0;
    jpeg_set_marker_processor(&cinfo, JPEG_COM, jpeg_handle_marker);
    jpeg_set_marker_processor(&cinfo, JPEG_APP0+15, jpeg_handle_marker);
    for (i=1;i<14;i++)
      jpeg_set_marker_processor(&cinfo, JPEG_APP0+i, jpeg_handle_marker);
  }

  jpeg_read_header(&cinfo,TRUE);

  jpeg_global.n_tables = 0;

  for (slot=0;slot<2;slot++)				// read quantization table
    if (cinfo.quant_tbl_ptrs[slot])                     // Assumption: 2 tables
    {
      jpeg_global.n_tables++;
      for (i=0;i<DCTSIZE2;i++)
        jpeg_global.tables[slot][(i&7)*8+(i>>3)] =
	  cinfo.quant_tbl_ptrs[slot]->quantval[JPEG_ZIGZAG(i)];
    } //also end of for() !!!

  jpeg_global.cpos = cinfo.num_components;              //n.b. cpos is num_components!!!!

  if (read_job & JOB_READ_COEFF) {		       	// read DCT coeffs

    JBLOCKARRAY buffer;
    JCOEFPTR blockptr;
    JDIMENSION block_row_num, block_col_num;
    jpeg_component_info *compptr;
    JQUANT_TBL * qtable;
    int ci, coefi;
    int * p;

    jvirt_barray_ptr * coef_arrays = jpeg_read_coefficients(&cinfo);

    if (cinfo.num_components > MAX_JCOMPONENTS){
      jpeg_destroy_decompress(&cinfo);
      error("too many components");
    }

    //by Nils, set width and height in jpeg_global
    //was only correct in pixel data :-(
    jpeg_global.dx = cinfo.image_width;
    jpeg_global.dy = cinfo.image_height;

    //for each component
    for (ci = 0; ci < cinfo.num_components; ci++) {
      compptr = cinfo.comp_info + ci;
      qtable = compptr->quant_table;

      jpeg_global.coeff[ci] = p = (int*)R_alloc(DCTSIZE2*compptr->height_in_blocks*compptr->width_in_blocks,sizeof(int));
      jpeg_global.bdx[ci] = compptr->width_in_blocks;
      jpeg_global.bdy[ci] = compptr->height_in_blocks;
      //for each row
      for (block_row_num = 0; block_row_num < compptr->height_in_blocks;block_row_num++) {
	buffer = (*cinfo.mem->access_virt_barray)
	  ((j_common_ptr) &cinfo, coef_arrays[ci],
	   block_row_num, (JDIMENSION) 1, FALSE);
        //for each column
	for (block_col_num = 0; block_col_num < compptr->width_in_blocks;block_col_num++) {
	  blockptr = buffer[0][block_col_num];
          //process an 8x8 matrix
	  for (coefi = 0; coefi < DCTSIZE2; coefi++) {
	    int cval = blockptr[(coefi&7)*8+(coefi>>3)];  // fit R row-col structure
	    if (read_job & JOB_DEQUANTIZE)
	       cval *= qtable->quantval[(coefi&7)*8+(coefi>>3)];
	    *(p++) = cval;
	  }
	}
      }
    }
  } //end read coefficients
  else {  						// read pixel data

    if (read_job & JOB_FANCYUPSAMPLING)
	     cinfo.do_fancy_upsampling = TRUE;
    else
	     cinfo.do_fancy_upsampling = FALSE;
 
    if (cinfo.jpeg_color_space != JCS_RGB)
      cinfo.out_color_space = JCS_RGB;                //libjpeg converts to RGB

    // GREYMAP

     if (cinfo.num_components==1)
      {//printf("isgrey!!! \n");
       //printf("numcomp: %i \n",cinfo.num_components);
       isgrey=1;
       bytesperpixel=1; //only one byte per pixel=brightness
       cinfo.out_color_space=JCS_GRAYSCALE;
      }
     else //RGB
      {isgrey=0; //False
       bytesperpixel=3; //rgb for each pixel
       cinfo.out_color_space=JCS_RGB;
      }


    jpeg_start_decompress(&cinfo);


    jpeg_global.dx = cinfo.output_width;
    jpeg_global.dy = cinfo.output_height;

    //alloc a complete pixel image in jpeg_global.data

    jpeg_global.data = R_alloc(cinfo.output_width*cinfo.output_height,bytesperpixel);

    sl = jpeg_global.data;  //working copy of data

    //bytesperpixel=3; //1 fuer greymap

    while (cinfo.output_scanline < cinfo.output_height) {
      jpeg_read_scanlines(&cinfo,&sl,1);
      sl += bytesperpixel*cinfo.output_width;  //copying destination now one row further...
    }
  } //end pixel specific part

  fclose(f);
  jpeg_finish_decompress(&cinfo);
  jpeg_destroy_decompress(&cinfo);

  return 0;
}

// JPEG Import Functions

//calls jpeg_do_read with some jobs
//n.b. p and P are different variables :-(
SEXP jpeg_read_rgb(SEXP file, SEXP fancy_upsampling)
{ char * filename = CHAR(PROTECT(asChar(file)));
  SEXP ans, names, class, mark, marknames;
  SEXP red, green, blue;
  SEXP tables[2], tdim, tlist, tnames;
  int dx, dy, x, y, i, k, slot, P = 1;
  int isgrey;
  int channelsize; //number of img data vectors needed
  unsigned char * p;
  int have_markers;

  jpeg_do_read(filename,JOB_READ_PIXEL|JOB_MARKERS|((asLogical(fancy_upsampling))?JOB_FANCYUPSAMPLING:0));

  dx = jpeg_global.dx;
  dy = jpeg_global.dy;
  p  = jpeg_global.data; //p is a copy of image data ptr

  //printf("jpeg_global.cpos= %i \n",jpeg_global.cpos);
  if (jpeg_global.cpos==1)
   {//greymap
   isgrey=1;
   }
  else
   {//rgbmap
   isgrey=0;
   }


  // check for markers (jpeg comments)

  if (have_markers = (jpeg_global.mpos>0)?1:0) {
    PROTECT(mark = allocVector(STRSXP,jpeg_global.mpos)); P++;
    PROTECT(marknames = allocVector(STRSXP,jpeg_global.mpos)); P++;
    for (i=0;i<jpeg_global.mpos;i++) {
      SET_STRING_ELT(mark, i, mkChar(jpeg_global.mark[i]));
      SET_STRING_ELT(marknames, i, mkChar(jpeg_global.mname[i]));//
    }
    setAttrib(mark, R_NamesSymbol, marknames);
  }

  // store pixel data in matrices
  //P counts PROTECT() calls
  PROTECT(red   = allocMatrix(REALSXP, dy, dx)); P++;
  PROTECT(green = allocMatrix(REALSXP, dy, dx)); P++;
  PROTECT(blue  = allocMatrix(REALSXP, dy, dx)); P++;

  if(!isgrey)  //rgb
  {
   for (y=0;y<dy;y++)
     for(x=0;x<dx;x++) {
       REAL(red)[dy*x+y]   = ((double)*(p++))/255; //p used
       REAL(green)[dy*x+y] = ((double)*(p++))/255;
       REAL(blue)[dy*x+y]  = ((double)*(p++))/255;
     }
  }
  else //isgrey -> input array is much smaller
  {

  for (y=0;y<dy;y++)
     for(x=0;x<dx;x++) {
       REAL(red)[dy*x+y]   = ((double)*(p))/255; //p used
       REAL(green)[dy*x+y] = ((double)*(p))/255;
       REAL(blue)[dy*x+y]  = ((double)*(p))/255;
       p++;
     }

  }

  if(isgrey)channelsize=1;
  else channelsize=3;  //red green and blue

  // create list of red, green and blue matrices

  PROTECT(ans = allocVector(VECSXP,2+channelsize+have_markers)); P++;

  SET_VECTOR_ELT(ans, 0, red);
  if(!isgrey)
  {
  SET_VECTOR_ELT(ans, 1, green);
  SET_VECTOR_ELT(ans, 2, blue);
  }
  //channelsize+1 will become tables..

  SET_VECTOR_ELT(ans, channelsize, file);

  if (have_markers)
    SET_VECTOR_ELT(ans, channelsize+2, mark);

  // store quantization tables

  PROTECT(tlist = allocVector(VECSXP,jpeg_global.n_tables)); P++;
  PROTECT(tdim = allocVector(INTSXP,2)); P++;
  INTEGER(tdim)[0] = INTEGER(tdim)[1] = DCTSIZE;

  for (slot=0;slot<jpeg_global.n_tables;slot++)
  {
    PROTECT(tables[slot] = allocVector(INTSXP, DCTSIZE2)); P++;

    for (k=0;k<DCTSIZE2;k++)
      INTEGER(tables[slot])[k] = jpeg_global.tables[slot][k];

    setAttrib(tables[slot], R_DimSymbol, tdim);
    SET_VECTOR_ELT(tlist, slot, tables[slot]);
  }

  PROTECT(tnames = allocVector(VECSXP,jpeg_global.n_tables)); P++;
  SET_VECTOR_ELT(tnames, 0, mkChar(LABEL_LUMINANCE));

  if (jpeg_global.n_tables>1)
    SET_VECTOR_ELT(tnames, 1, mkChar(LABEL_CHROMINANCE));

  setAttrib(tlist, R_NamesSymbol, tnames);

  SET_VECTOR_ELT(ans, channelsize+1, tlist);

  // add element names


  PROTECT(names = allocVector(VECSXP,2+channelsize+have_markers)); P++;

  if(isgrey)SET_VECTOR_ELT(names, 0, mkChar(LABEL_GREY));
   else     SET_VECTOR_ELT(names, 0, mkChar(LABEL_RED ));

  if(!isgrey)
  {SET_VECTOR_ELT(names, 1, mkChar(LABEL_GREEN));
   SET_VECTOR_ELT(names, 2, mkChar(LABEL_BLUE));
  }

  SET_VECTOR_ELT(names, channelsize, mkChar(LABEL_NAME));
  SET_VECTOR_ELT(names, channelsize+1, mkChar(LABEL_TABLES));

  if (have_markers)
    SET_VECTOR_ELT(names, channelsize+2, mkChar(LABEL_MARKER));

  setAttrib(ans, R_NamesSymbol, names);

  // set class "rgbmap" or "greymap"

  PROTECT(class = allocVector(STRSXP,1)); P++;
  if(isgrey) SET_STRING_ELT(class, 0, mkChar(LABEL_GREYMAP));
  else       SET_STRING_ELT(class, 0, mkChar(LABEL_RGBMAP));

  classgets(ans,class);

  UNPROTECT(P);//10+(have_markers*2)+jpeg_global.n_tables);
  return ans;
}

////////////////////////////////
//calls jpeg_do_read with jobs
//builts R data structures
//using data from jpeg_global
//////////////////////////////
SEXP jpeg_read_coeff(SEXP file,SEXP dequantize)
{
	char * filename = CHAR(PROTECT(asChar(file)));
	SEXP ans, names, class;
	SEXP tables[2], tlist, tdim, tnames;
	SEXP comp[MAX_JCOMPONENTS];
	SEXP dims[MAX_JCOMPONENTS];
	SEXP S_width;  //width value in dctmap
	SEXP S_height; //height value in dctmap
	SEXP S_mark;
	SEXP S_marknames;
	SEXP S_spatialdim;
	SEXP S_spatialdimnames;

	int ci, k, slot;
	int i;
	int * p;
	int P = 1;
	int have_markers;    //are there markers?
	int markersize;     //num of dctmap elements needed for marker data
	int spatialdimsize;  //num of dctmap elements needed for size data
	int filenamesize;    //num of dctmap elements needed for filename

	char * comp_names[] = {LABEL_Y,LABEL_CB,LABEL_CR};  //earlier versions had wrong order

	jpeg_do_read(filename,JOB_MARKERS|JOB_READ_COEFF|((asLogical(dequantize))?JOB_DEQUANTIZE:0));

	//read info is now in jpeg_global
	// create a list of components
	if (jpeg_global.mpos>0) {
		//printf("have markers !!!\n");
		markersize=1; //we need space for dctmap$marker entry
	}else{
		markersize=0;
	}

	filenamesize=1;
	spatialdimsize=1; //need space for dctmap$spatial.dim
	PROTECT(ans = allocVector(VECSXP,jpeg_global.cpos+1+spatialdimsize+
		markersize+filenamesize) ); P++;

	// store DCT coefficients in R structure
	
	//alloc e.g. 3 components; bdx= number of blocks in x direction e.g. bdx=10 -> 80 pixel
	for (ci=0;ci<jpeg_global.cpos;ci++) {  //cpos=num_componets !!!
		//alloc width*height*64
		PROTECT(comp[ci] = allocVector(INTSXP, jpeg_global.bdx[ci]*jpeg_global.bdy[ci]*DCTSIZE2)); P++;
		p = jpeg_global.coeff[ci];

		for (k=0;k<jpeg_global.bdy[ci]*jpeg_global.bdx[ci]*DCTSIZE2;k++)
			INTEGER(comp[ci])[k] = *(p++);

		//data written sequential, complex structure added later

		PROTECT(dims[ci] = allocVector(INTSXP,4)); P++;   //alloc another 4 ints
		INTEGER(dims[ci])[3] = jpeg_global.bdy[ci];
		INTEGER(dims[ci])[2] = jpeg_global.bdx[ci];
		INTEGER(dims[ci])[0] = INTEGER(dims[ci])[1] = DCTSIZE;

		//[0]=8;[1]=8;[2]=width;[3]=height

		//add 4 ints to comp[ci]
		setAttrib(comp[ci], R_DimSymbol, dims[ci]);
		SET_VECTOR_ELT(ans, ci, comp[ci]);
	}

	// store quantization tables

	PROTECT(tlist = allocVector(VECSXP,jpeg_global.n_tables)); P++;
	PROTECT(tdim = allocVector(INTSXP,2)); P++;
	INTEGER(tdim)[0] = INTEGER(tdim)[1] = DCTSIZE;

	for (slot=0;slot<jpeg_global.n_tables;slot++)
	{
		PROTECT(tables[slot] = allocVector(INTSXP, DCTSIZE2)); P++;

		for (k=0;k<DCTSIZE2;k++)
			INTEGER(tables[slot])[k] = jpeg_global.tables[slot][k];

		setAttrib(tables[slot], R_DimSymbol, tdim);
		SET_VECTOR_ELT(tlist, slot, tables[slot]);
	}

	PROTECT(tnames = allocVector(VECSXP,jpeg_global.n_tables));
	P++;
	SET_VECTOR_ELT(tnames, 0, mkChar(LABEL_LUMINANCE));
	if (jpeg_global.n_tables>1)
		SET_VECTOR_ELT(tnames, 1, mkChar(LABEL_CHROMINANCE));

	setAttrib(tlist, R_NamesSymbol, tnames);

	SET_VECTOR_ELT(ans, jpeg_global.cpos, tlist);

	// add element names

	//spatial.dim and markers need a name, too

	PROTECT(names = allocVector(VECSXP,jpeg_global.cpos+1+spatialdimsize+
		markersize+filenamesize)); 
	P++;

	for (ci=0;ci<jpeg_global.cpos;ci++)
		SET_VECTOR_ELT(names, ci, mkChar(comp_names[ci]));

	SET_VECTOR_ELT(names, jpeg_global.cpos, mkChar(LABEL_TABLES));

	SET_VECTOR_ELT(names, jpeg_global.cpos+spatialdimsize , mkChar(LABEL_SPATIALDIM)); //NILS

	if(markersize)
	{
		SET_VECTOR_ELT(names, jpeg_global.cpos+spatialdimsize+markersize , mkChar(LABEL_MARKER)); //NILS
	}

	SET_VECTOR_ELT(names, jpeg_global.cpos+spatialdimsize+markersize+filenamesize , mkChar(LABEL_NAME)); //NILS

	setAttrib(ans, R_NamesSymbol, names);

	// set class "dctmap"

	PROTECT(class = allocVector(STRSXP,1)); P++;
	SET_STRING_ELT(class, 0, mkChar(LABEL_DCTMAP));
	classgets(ans,class);

	//by Nils: fill spatial.dim and markers and set names for them
	//
	//

	PROTECT(S_spatialdim = allocVector(INTSXP,2)); P++;
	PROTECT(S_spatialdimnames = allocVector(STRSXP,2)); P++;
	INTEGER(S_spatialdim)[0]=jpeg_global.dx;
	INTEGER(S_spatialdim)[1]=jpeg_global.dy;

	SET_STRING_ELT(S_spatialdimnames, 0, mkChar(LABEL_WIDTH));
	SET_STRING_ELT(S_spatialdimnames, 1, mkChar(LABEL_HEIGHT));
	setAttrib(S_spatialdim, R_NamesSymbol, S_spatialdimnames);

	SET_VECTOR_ELT(ans, jpeg_global.cpos+spatialdimsize,S_spatialdim);

	//save markers from jpeg_global
	// check for markers (jpeg comments)

	if (have_markers = (jpeg_global.mpos>0)?1:0) {
		//printf("have markers !!!\n");
		PROTECT(S_mark = allocVector(STRSXP,jpeg_global.mpos));
		P++;
		PROTECT(S_marknames = allocVector(STRSXP,jpeg_global.mpos));
		P++;
		for (i=0;i<jpeg_global.mpos;i++) {
			SET_STRING_ELT(S_mark, i, mkChar(jpeg_global.mark[i]));
			SET_STRING_ELT(S_marknames, i, mkChar(jpeg_global.mname[i]));//
		}
		setAttrib(S_mark, R_NamesSymbol, S_marknames);
	}
	
	if (have_markers)
	{
		SET_VECTOR_ELT(ans, jpeg_global.cpos+spatialdimsize+markersize,S_mark);
	}

	SET_VECTOR_ELT(ans, jpeg_global.cpos+spatialdimsize+markersize+filenamesize,file);

	UNPROTECT(P); //7+2*jpeg_global.cpos+jpeg_global.n_tables+spatial.dim+marker..
	return ans;
}


////////////////////////////////////////
// JPEG Export Functions
// writes a rgbmap or a greymap to disk
////////////////////////////////////////
SEXP jpeg_write_rgb_dct(SEXP map,SEXP file,SEXP quality,SEXP overwrite,SEXP dctmethod,SEXP S_isgrey)
{ char * filename = CHAR(PROTECT(asChar(file)));
  FILE * f;
  int x,y,q = -1;
  unsigned char * buffer;
  SEXP red, green, blue, tlist, tables[2], marker;
  SEXP S_grey;
  struct jpeg_compress_struct cinfo;
  struct jpeg_error_mgr jerr;
  int isRGB,isGrey,bytesPerPixel;
  int num_qtbl;

  memset(&cinfo,0x00,sizeof(cinfo));
  memset(&jerr,0x00,sizeof(jerr));

  // check call parameters

  if (isNull(map)) error("%s or %s required",LABEL_RGBMAP,LABEL_GREYMAP);
  if (isNull(file)) error("filename required");



  if(asLogical(S_isgrey))
   {
   //printf("ist grey ...");
   isRGB = 0;
   isGrey=1;
   num_qtbl=1;
   }
  else
   {
   //printf("is not grey");
   isRGB=1;
   isGrey=0;
   num_qtbl=2;
  }

  if (!isNull(quality)) {
    SEXP qual;
    PROTECT(qual = coerceVector(quality,REALSXP));
    q = (int)(REAL(qual)[0]*100);
    if ((q>100)||(q<0))
      error("parameter quality is expected in the interval [0,1]");
    UNPROTECT(1); //SEXP qual no longer necessary
  }

  //printf("zugriff auf zu hohe qtables:..\n");
  if (q<0) {  //Qtables are given, quality should NOT be changed
    if (tlist = getListElement(map,LABEL_TABLES)) {
      int i, slot;
      for (slot=0;slot<num_qtbl;slot++) {         //number of qtables implizit 2 !!!
	PROTECT(tables[slot] = coerceVector(VECTOR_ELT(tlist,slot),INTSXP));
	for (i=0;i<DCTSIZE2;i++) {
	  jpeg_global.tables[slot][JPEG_ZIGZAG((i&7)*8+(i>>3))] = INTEGER(tables[slot])[i];
	}
      }
      UNPROTECT(num_qtbl);
    }
    else
      error("no quantization tables provided. set quality parameter to create tables.");
  }
  //printf("done\n");
  if(isRGB){
   red 	= getListElement(map,LABEL_RED);   //red is SEXP
   green = getListElement(map,LABEL_GREEN); //green gets whole component
   blue  = getListElement(map,LABEL_BLUE);

   if (!(red && green && blue))
       error("at least one component is missing or can't be coerced to numeric");
   }
  else//(isGrey)
   {
   S_grey = getListElement(map,LABEL_GREY);
   if(!S_grey)
     error("map$grey not found or not coercable to numeric");
   }

  // try opening output file


  check_overwrite(filename,overwrite);

  if (!(f = fopen(filename, "wb")))
    error("unable to create file %s",filename);

  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_compress(&cinfo);
  jpeg_stdio_dest(&cinfo,f);

  if(isRGB)
   {cinfo.image_width  	 = INTEGER(getAttrib(red,R_DimSymbol))[1];
    cinfo.image_height 	 = INTEGER(getAttrib(red,R_DimSymbol))[0];
    cinfo.input_components = 3;
    cinfo.in_color_space   = JCS_RGB;
   }
  else //isGrey
   {cinfo.image_width  	 = INTEGER(getAttrib(S_grey,R_DimSymbol))[1];
    cinfo.image_height 	 = INTEGER(getAttrib(S_grey,R_DimSymbol))[0];
    cinfo.input_components = 1;
    cinfo.in_color_space   = JCS_GRAYSCALE;
   }

  // handle quality and quantization tables

  jpeg_set_defaults(&cinfo);

  //printf("addqtable:\n");
  if (q>=0)
    jpeg_set_quality(&cinfo,q,FALSE);
  else {
    jpeg_add_quant_table(&cinfo,0,jpeg_global.tables[0],100,FALSE);
    if(isRGB)jpeg_add_quant_table(&cinfo,1,jpeg_global.tables[1],100,FALSE);
  }
  //printf("done\n");
  // set optional DCT method

  if (!isNull(dctmethod))
  {
    SEXP method;
    PROTECT(method = coerceVector(dctmethod,INTSXP));

    switch (INTEGER(method)[0])
    {
	case 1 : cinfo.dct_method = JDCT_ISLOW;
	         break;
	case 2 : cinfo.dct_method = JDCT_IFAST;
	         break;
	case 3 : cinfo.dct_method = JDCT_FLOAT;
	         break;
    }

    UNPROTECT(1);
  }
  jpeg_start_compress(&cinfo,TRUE);

  // write markers (TODO: write all markers, not only comment)

  if (marker=getListElement(map,LABEL_MARKER)) {
    SEXP names = getAttrib(marker, R_NamesSymbol);
    int i;
    for (i = 0; i < length(marker); i++)
      if(strcmp(CHAR(STRING_ELT(names, i)), "COM") == 0) {
	SEXP text = STRING_ELT(marker,i);
	jpeg_write_marker(&cinfo,JPEG_COM,CHAR(text),strlen(CHAR(text)));
      }
  }

  //marker done, write actual image data

  // write scanlines

  if(isRGB)
  {bytesPerPixel=3;}
  else
  {bytesPerPixel=1;}

  buffer = R_alloc(cinfo.image_width,bytesPerPixel);
  y = 0;

  if(isRGB)
  {
  while (cinfo.next_scanline<cinfo.image_height) {
    char * b = buffer;
    for (x=0;x<cinfo.image_width;x++) {
      (*b++) = (unsigned char)(255*REAL(red)[cinfo.image_height*x+y]);
      (*b++) = (unsigned char)(255*REAL(green)[cinfo.image_height*x+y]);
      (*b++) = (unsigned char)(255*REAL(blue)[cinfo.image_height*x+y]);
    }
    jpeg_write_scanlines(&cinfo,(JSAMPROW*)&buffer,1);
    y++;
  }
  }
  else //isGrey
  {
  while (cinfo.next_scanline<cinfo.image_height) {
    char * b = buffer;
    for (x=0;x<cinfo.image_width;x++) {
      (*b++) = (unsigned char)(255*REAL(S_grey)[cinfo.image_height*x+y]);
     // (*b++) = (unsigned char)(255*REAL(green)[cinfo.image_height*x+y]);
     // (*b++) = (unsigned char)(255*REAL(blue)[cinfo.image_height*x+y]);
    }
    jpeg_write_scanlines(&cinfo,(JSAMPROW*)&buffer,1);
    y++;
  }
  }//end isgrey

  jpeg_finish_compress(&cinfo);
  jpeg_destroy_compress(&cinfo);

  fclose(f);
  UNPROTECT(1);
  return file;

} //end of jpeg_write_rgb_grey

//write_jpeg_dct helper functions:


//computes (from dimension(height or width)
//and 8x8 block number (in the same direction)
//the factor, blocks have to be zoomed with to cover
//the picture
//e.g. picture dimension=18 (width)
//e.g. blocknumber =1 (in x direction)
// =>simplefactor = 3, i.e.  3*8 is smallest => 18
//                  58                 8
int simplefactor(int ausdehnung,int blockzahl)
{
int blockabdeckung=0; //no of pix covered by faktor*blockzahl
int faktor = 0; //will be increased prior to first usage, see below

//shouldnt happen ...
if ((ausdehnung)<0) ausdehnung=ausdehnung*(-1);
if ((blockzahl )<0) blockzahl =blockzahl *(-1);
do
 {
 faktor++;
 blockabdeckung=faktor*8*blockzahl;
 }
while (blockabdeckung<ausdehnung);
return(faktor);
}//end simplefactor

//computes from 3 simplefactors the sampling factors needed by libjpeg
//anendung fuer horiz unt vertical unabh voneinander
//bsp: sfY=5   //also muesste man um faktor 5 strecken->mcu vielfache von 5
//     sfCr=2  //also muesste man um faktor 2 strecken->mcu vielfache von 2
//     sfCb=3  //also muesste man um faktor 3 strecken->mcu vielfache von 3
//mcudim waere 30 (!!!)
//also die gesuchten faktoren:
//Y_h_samp=30/5  = 6  -> diese faktoren stehen in der datei
//Cr_h_samp=30/2 =15
//Cb_h_samp=30/3  =10

//compute dimension of a jpeg minimal coding unit
//gets simplefactors for all components
int jpegmcudimension (int sfY,int sfCr,int sfCb)
{
int mcudim;
mcudim=lcmpos(lcmpos(sfY,sfCr),sfCb);
//=lcm(lcm(sfY,sfCr),sfCb); //mathworld
//lcm(a,b)=a*b/gcd(a,b) //mathworld
return(mcudim);
}

//computes the greatest common divisor of 2 positive numbers
//not *that* efficient ...
//sideeffect: huge stack usage
int gcd(int a, int b)
{
int temp;
int rest;

if(a<b){temp=a; a=b; b=temp;} //if(a<b) swap(a,b)

rest=a%b;

if(rest==0){return(b);}
else       {return(gcd(b,rest));}

}

// computes lowest common multiple (german: kgV) using gcd
int lcmpos (int a, int b)
{
if(a<0)a=a*(-1);
if(b<0)b=b*(-1);

return((a*b)/gcd(a,b));
}



//////////////////////////////////////////////////////////////////////
//writing an dctmap to disc
//
//
//S_isgrey tells, whether Cr Cb and Crom. are existing
///////////////////////////////////////////////////////////////////////
SEXP write_jpeg_dct(SEXP S_filename,SEXP S_dctmap,SEXP S_overwrite,SEXP S_isgrey)
{
char * filename =CHAR(PROTECT(asChar(S_filename)));
struct jpeg_compress_struct cinfo;
struct jpeg_error_mgr jerr;
FILE * outfile;
unsigned int P; //protectcounter
int c,x,y,i;
int usedqtables; //genutzteqtables;
int heights_inBlocks[3]; //hoehen_achtheiten[3];   // =1 if  grey
int widths_inBlocks[3];
int widthYinBlocks,heightYinBlocks;
int widthCrinBlocks,heightCrinBlocks;  //dimensions of map$Cr
int widthCbinBlocks,heightCbinBlocks;
int maxheightinblocks,maxwidthinblocks;
int * intzeiger;
UINT16 uint16wert;
int xbl,ybl;
int coeffprozeile;
int notgrey;
int grey;
int imageheight; //bildhoehe;
int imagewidth;
int sfY_width,sfY_height;       //simplefactor
int sfCr_width,sfCr_height;
int sfCb_width,sfCb_height;
int mcudim_height,mcudim_width; //width and height of an  mcu

SEXP S_YList,S_CrList,S_CbList; //the actual dct data
SEXP S_marker;
SEXP S_spatialdim;
SEXP S_tables,S_luminance,S_chrominance;
jvirt_barray_ptr * coeff_arrays=NULL;
jpeg_component_info * comp_ptr;
JBLOCKARRAY zeilenpuffer;
JCOEFPTR puffer_ptr;
JCOEF jcoefwert;
SEXP S_width,S_height;


//printf("writejpegdct called \n");

if(asLogical(S_isgrey))
{
//printf("ist grey ...");
notgrey = 0; //false -> is grey
grey=1;
} else
{
//printf("is not grey");
notgrey = 1;
grey=0;
}


if (!grey){
 usedqtables = 2; //Y and  Cr/Cb used  //no of used tables
 }else // is grey
 {
 usedqtables = 1; //only Y used
}


check_overwrite(filename,S_overwrite);

outfile=fopen(filename,"wb");
if (outfile==NULL)error("open outputfile failed\n");

cinfo.err=jpeg_std_error(&jerr);

jpeg_create_compress(&cinfo);
jpeg_stdio_dest(&cinfo,outfile);

//CAUTION: getListElement is overloaded, how funny :-(

S_YList=getListElement(S_dctmap,LABEL_Y);  //S_YLIST <- dctmap$Y

if(!grey)
{
 S_CrList=getListElement(S_dctmap,LABEL_CR);
 S_CbList=getListElement(S_dctmap,LABEL_CB);
}

S_spatialdim=getListElement(S_dctmap,LABEL_SPATIALDIM);
imagewidth=INTEGER(S_spatialdim)[0];
imageheight =INTEGER(S_spatialdim)[1];

// printf("imagewidth %i \n",imagewidth);  //ok, neue form geht :-)
// printf("imageheight  %i \n",imageheight );


//image_width etc berechnen:
widthYinBlocks=INTEGER(getAttrib(S_YList,R_DimSymbol))[2];  //geht
heightYinBlocks =INTEGER(getAttrib(S_YList,R_DimSymbol))[3];  //geht

if(!grey){
 widthCbinBlocks=INTEGER(getAttrib(S_CbList,R_DimSymbol))[2];
 heightCbinBlocks =INTEGER(getAttrib(S_CbList,R_DimSymbol))[3];
 widthCrinBlocks=INTEGER(getAttrib(S_CrList,R_DimSymbol))[2];
 heightCrinBlocks =INTEGER(getAttrib(S_CrList,R_DimSymbol))[3];
}
 else //dochgrey
{ //noch noetig fuer max3
 widthCrinBlocks=1;//INTEGER(getAttrib(S_CrListe,R_DimSymbol))[2];
 heightCrinBlocks =1;//INTEGER(getAttrib(S_CrListe,R_DimSymbol))[3];
 widthCbinBlocks=1;//INTEGER(getAttrib(S_CbListe,R_DimSymbol))[2];
 heightCbinBlocks =1;//INTEGER(getAttrib(S_CbListe,R_DimSymbol))[3];
}

/*
printf("widthYinBlocks = %i \n",widthYinBlocks);
printf("heightYinBLocks  = %i \n",heightYinBlocks);
printf("widthCrinBlocks = %i \n",widthCrinBlocks);
printf("heightCrinBLocks  = %i \n",heightCrinBlocks);
printf("widthCbinBlocks = %i \n",widthCbinBlocks);
printf("heightCbinBLocks  = %i \n",heightCbinBlocks);
//printf("imagewidth %i \n",imagewidth);
//printf("imageheight  %i \n",imageheight );
printf("simplefactor(ausd=18, blockz=1)=%i \n",simplefactor(18,1));
printf("simplefactor(ausd=5,  blockz=1)=%i \n",simplefactor(5,1));
printf("simplefactor(ausd=8,  blockz=1)=%i \n",simplefactor(8,1));
printf("simplefactor(ausd=16, blockz=1)=%i \n",simplefactor(16,1));

printf("simplefactor(ausd=18, blockz=2)=%i \n",simplefactor(18,2));
printf("simplefactor(ausd=5,  blockz=1)=%i \n",simplefactor(5,1));
printf("simplefactor(ausd=58,  blockz=8)=%i \n",simplefactor(58,8));
printf("simplefactor(ausd=48, blockz=6)=%i \n",simplefactor(48,6));

printf("jpegmcudimension(5,2,3)=%i \n",jpegmcudimension(5,2,3));
*/

//berechnung der samplingfactoren aus groesse:
//width und height neu auslesen fehlt noch:

sfY_width =simplefactor(imagewidth,widthYinBlocks);
sfY_height  =simplefactor(imageheight,heightYinBlocks);
if(!grey){
 sfCb_width=simplefactor(imagewidth,widthCbinBlocks);
 sfCb_height =simplefactor(imageheight,heightCbinBlocks);
 sfCr_width=simplefactor(imagewidth,widthCrinBlocks);
 sfCr_height =simplefactor(imageheight,heightCrinBlocks);

 }
 else //grey
 {
 sfCb_width=1;//simplefactor(imagewidth,widthCbinBlocks);
 sfCb_height =1;//simplefactor(imageheight,heightCbinBlocks);
 sfCr_width=1;//simplefactor(imagewidth,widthCrinBlocks);
 sfCr_height =1;//simplefactor(imageheight,heightCrinBlocks);

}

mcudim_width=jpegmcudimension(sfY_width,sfCr_width,sfCb_width);
mcudim_height =jpegmcudimension(sfY_height,sfCr_height,sfCb_height);


cinfo.image_width=imagewidth;
cinfo.image_height=imageheight;

if(!grey)
 {
 cinfo.input_components=3;
 cinfo.num_components=3;
 cinfo.in_color_space=JCS_YCbCr;
 }
 else // is grey
 {
 cinfo.input_components=1;
 cinfo.num_components=1;
 cinfo.in_color_space=JCS_GRAYSCALE;
}

jpeg_set_defaults(&cinfo); //alloc comp_info structures
	
// This is necessary for compatibility with libjpeg >= 8b:
// Normally jpeg_start_compress calculates the default values, but we don't use it here,
// so we have to use the following function.

if(JPEG_LIB_VERSION >= 70){
jpeg_calc_jpeg_dimensions(&cinfo);

//printf("cinfo.min_DCT_h_scaled_size = %i\n",cinfo.min_DCT_h_scaled_size);
//printf("cinfo.min_DCT_v_scaled_size = %i\n",cinfo.min_DCT_v_scaled_size);
//printf("cinfo.jpeg_height = %i\n",cinfo.jpeg_height);
//printf("JPEG VERSION %i",JPEG_LIB_VERSION);
}

//strategie fuer errechnung der samplingfaktoren
//*bei grey irrelevant, da nur 1 komponente *
//errechnen der widthnfaktoren (*1 .. *4)
//d.h. wie weit wurde die komponente runtergesampled
//z.B. Y*1 (relat zu 8*8 natuerlich)
//z.B. Cr*2
// -> kgV (1,2) = 2 = anz 8x8 bloecke in mcu
// hmcuzahl= if(width/)

/*if((imagewidth%8)==0) //8x8 bloecke optimal genutzt :-)
{block8width = imagewidth / 8; }
else
{block8width =(imagewidth/8)+1;}

if((imageheight%8)==0) //8x8 bloecke optimal genutzt :-)
{block8height = imageheight / 8; }
else
{block8height =(imageheight /8)+1;}
*/
//bsp block8height  = 3  //18
//    block8width = 1  //8

//Y_mcuheight = block8height / Y_height; //wieviele Y felder in einem mcu, zb 2

//widthYinBlocks gibt es
//imagewidth und imageheight sind jetzt verfuegbar

//hier jetzt die neuen Erkenntnisse:
//

cinfo.comp_info[0].component_id=0;
cinfo.comp_info[0].h_samp_factor=mcudim_width/sfY_width;//2;
 //wieviele 8x8 felder in einer mcu stehen
cinfo.comp_info[0].v_samp_factor=mcudim_height/sfY_height;//2;
cinfo.comp_info[0].quant_tbl_no=0;


if(!grey)
{
 cinfo.comp_info[1].component_id=1;
 cinfo.comp_info[1].h_samp_factor=mcudim_width/sfCb_width;//1;
 cinfo.comp_info[1].v_samp_factor=mcudim_height/sfCb_height; //1;
 cinfo.comp_info[1].quant_tbl_no=1;

 cinfo.comp_info[2].component_id=2;
 cinfo.comp_info[2].h_samp_factor=mcudim_width/sfCr_width;//1;
 cinfo.comp_info[2].v_samp_factor=mcudim_height/sfCr_height;//1;
 cinfo.comp_info[2].quant_tbl_no=1;

}

heights_inBlocks[0]=heightYinBlocks;
heights_inBlocks[1]=heightCbinBlocks;  //=1 if grey
heights_inBlocks[2]=heightCrinBlocks;

widths_inBlocks[0]=widthYinBlocks;
widths_inBlocks[1]=widthCbinBlocks;
widths_inBlocks[2]=widthCrinBlocks;  //cr and cb now fixed

//printf("begin alloc \n");

//alloc space for 3 pointers
// coeff_arrays is an array of type virtual array.
// At first, we alloc space for this virtual arrays.
coeff_arrays=(jvirt_barray_ptr *) (cinfo.mem->alloc_small)
             ((j_common_ptr) &cinfo,
              JPOOL_IMAGE,
              sizeof(jvirt_barray_ptr) * (cinfo.num_components));

// Then, we create a virtual array for each array component
for(c=0;c<cinfo.num_components;c++)
 {
  comp_ptr=cinfo.comp_info+c;  //n.b. +c*sizeof(pointerziel)
  comp_ptr->height_in_blocks=heights_inBlocks[c];
  comp_ptr->width_in_blocks=widths_inBlocks[c];

  coeff_arrays[c]=(cinfo.mem->request_virt_barray)
                  ((j_common_ptr) &cinfo,
		  JPOOL_IMAGE,
		  TRUE, //zeroed
		  (JDIMENSION)jround_up((long)comp_ptr->width_in_blocks,  //component size in dct blocks (ignoring mcu)
		                        (long)comp_ptr->h_samp_factor),   //round up is important, if border MCUs are not completely needed
		  (JDIMENSION)jround_up((long)comp_ptr->height_in_blocks,
		                        (long)comp_ptr->v_samp_factor),
		  (JDIMENSION)(long)comp_ptr->v_samp_factor

		  );

 //width_in_blocks is number of necessary blocks without padding!!!
 //printf("verwendete daten:\n");
 //printf("comp_ptr->width_in_blocks=%i \n",comp_ptr->width_in_blocks);


 }// ende for()

	/*
	printf("cinfo.image_width = %i\n",cinfo.image_width);
	printf("cinfo.image_height = %i\n",cinfo.image_height);
	printf("cinfo.num_components = %i\n",cinfo.num_components);
	printf("cinfo.input_components = %i\n",cinfo.input_components);
*/

jpeg_write_coefficients(&cinfo,coeff_arrays);
//printf("nach jpegwritecoeff \n ");

// write markers (TODO: write all markers, not only comment)

 if (S_marker=getListElement(S_dctmap,LABEL_MARKER)) {
    SEXP names = getAttrib(S_marker, R_NamesSymbol);
    int i;
    for (i = 0; i < length(S_marker); i++)
      if(strcmp(CHAR(STRING_ELT(names, i)), "COM") == 0) {
	SEXP text = STRING_ELT(S_marker,i);
	jpeg_write_marker(&cinfo,JPEG_COM,CHAR(text),strlen(CHAR(text)));
      }
  }

// marker done, now writing picture data

//writing qtbl

S_tables=getListElement(S_dctmap,LABEL_TABLES);
S_luminance=getListElement(S_tables,LABEL_LUMINANCE);
S_chrominance=getListElement(S_tables,LABEL_CHROMINANCE);

//printf("dctmap$tables$luminance[1] = %i \n",coerceVector(VECTOR_ELT(S_luminance,1),INTSXP));

/*
intzeiger=(int *) (INTEGER(S_luminance));  //beginnend bei 0 wie in C

//achtung: REihenfolge geht nach unten!!!
for(i=0;i<DCTSIZE;i++)
printf("dctmap$tables$luminance[%i] = %i \n",i,intzeiger[i]);
*/
//luminance geht

//usedqtables is 1 if grey :-)
for(i = 0;i<usedqtables;i++)
{
  if (cinfo.quant_tbl_ptrs[i]==NULL)
   {
   cinfo.quant_tbl_ptrs[i]=jpeg_alloc_quant_table((j_common_ptr)&cinfo);
   }
  if(i==0)intzeiger=(int*)(INTEGER(S_luminance));
  if(i==1)intzeiger=(int*)(INTEGER(S_chrominance));
  if(i>1) intzeiger=(int*)(INTEGER(S_chrominance));
  for(y=0;y<DCTSIZE;y++)
    {
    for(x=0;x<DCTSIZE;x++)
     {
     //printf("zugriff_");
      uint16wert=(UINT16) intzeiger[y+DCTSIZE*x];
     //printf("y=%i x=%i y+DCTSIZE*x=%i\n ",y,x,y+DCTSIZE*x);
      cinfo.quant_tbl_ptrs[i]->quantval[y*DCTSIZE+x]=uint16wert;
      //traversing in normal array order

     }
    }
 //printf("next qtable\n");

} //end writing used qtables

//remaining qtblslots=NULL

for(i=usedqtables;i<NUM_QUANT_TBLS;i++)
 cinfo.quant_tbl_ptrs[i]=NULL;

///////////////////////////----------------------------------------------------
//now writing dctdata ---------------------------------------------------
S_YList  =getListElement(S_dctmap,LABEL_Y);
if(!grey){
 S_CrList =getListElement(S_dctmap,LABEL_CR);
 S_CbList =getListElement(S_dctmap,LABEL_CB);
}

//num_components is for grey =1
for(i = 0;i<cinfo.num_components;i++)
{
  //printf("bin in component forschleife, componente: %i \n",i);
  //order changed to libjpeg standard
  if(i==0)intzeiger=(int*)(INTEGER(S_YList));
  if(i==1)intzeiger=(int*)(INTEGER(S_CbList));
  if(i==2)intzeiger=(int*)(INTEGER(S_CrList));
  if(i>3 )error("Number of components > cinfo.input_components");
  comp_ptr=cinfo.comp_info+i; //i implicit i*(sizeof(ptr))

  //how much to advance to find next row?
  coeffprozeile =DCTSIZE2*(comp_ptr->width_in_blocks);

  for(y=0;y < (comp_ptr->height_in_blocks);y++) //for each row
   {
   //apply for access to row (libjpeg must swap in etc)
   zeilenpuffer=(cinfo.mem->access_virt_barray)
                ((j_common_ptr) &cinfo,
		 coeff_arrays[i],  //what memory area
		 y, //starting row  (0..n-1) //JDIMENSION
		    //access_array: access entire row
		 1, //number of rows
                 TRUE //writing
                );
   for(x=0;x < (comp_ptr->width_in_blocks);x++)
     {
      //printf("feld: y:%i x:%i \n",y,x);
      puffer_ptr=zeilenpuffer[0][x]; //y=0, only one row in buffer

       for(xbl=0;xbl<DCTSIZE;xbl++)  // x in Block
         {
         for(ybl=0;ybl<DCTSIZE;ybl++) // y in Block
           {
            //printf("z");
            jcoefwert=(JCOEF) intzeiger[(y*coeffprozeile)+(x*DCTSIZE2)+(xbl+(DCTSIZE*ybl))];
            //printf("%i ",jcoefwert);
	    //jcoefwert=xbl*ybl; // testing only!!!
	    puffer_ptr[xbl*DCTSIZE+ybl]=jcoefwert;
	    //traverse in normal array order




	   }// end 8x8block column
          //printf("\n");
	 }//end 8x8block row

     }//end per column
   }//end per row

//printf("next dct table\n, i ATM: %i \n",i);
//printf("cinfo.inputcomponents = %i \n",cinfo.input_components);
//printf("cinfo.num_components = %i\n",cinfo.num_components);

} //end used dct tables
//-------------------------------------------------------------------------


//printf("jpeg_finish_compress..\n");
jpeg_finish_compress(&cinfo);
jpeg_destroy_compress(&cinfo);


fclose(outfile);
UNPROTECT(1);
return(S_dctmap);
}
