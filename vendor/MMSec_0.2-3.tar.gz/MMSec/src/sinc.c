#include <R.h>
#include <Rmath.h>
#include <math.h>
#include <Rinternals.h>


/************ 
Routine for 2D-image resizing using SINC-interpolation
*************
* 
* 
*************/
SEXP scale_sinc(SEXP M, SEXP dim, SEXP support){
		
		SEXP temp,res;
		
		int 	i,j,k,h,w,N_h,N_w,s;
		int 	P = 0;
		long 	m;
		double 	z,xn,yn,sum,t;
		
		double 	*weights;
		long 	*index;
		
		N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
		N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
		
		long	N_w2 = 2L * N_w - 2L;
		long	N_h2 = 2L * N_h - 2L;
		
		h = INTEGER(dim)[0];
		w = INTEGER(dim)[1];
		s = INTEGER(support)[0];
		
		PROTECT(res = allocMatrix(REALSXP, h, w));
		P++;
		PROTECT(temp = allocMatrix(REALSXP, N_h, w));
		P++;
		
		index = (long *)R_alloc(s, sizeof(long));
		weights = (double *)R_alloc(s, sizeof(double));

		/***************************************
		***** interpolation in x-direction *****
		****************************************/

		z = ((double)N_w-1)/(w-1);
		for (i = 0; i < w; i++) { // iterate column-wise
			xn = z*i;  // new x-coordinate	
			/* compute the interpolation indexes */
			if (s & 1L) {
				m = (long)floor(xn + 0.5) - s/2L;
				for (k = 0; k < s; k++) 
					index[k] = m++;
			}
			else {
				m = (long)floor(xn) - s/2L + 1; //m = (long)floor(xn) - s/2L;
				for (k = 0; k < s; k++)
					index[k] = m++;
			}	
			
			/* compute the interpolation weights */
			for (k = 0; k < s; k++) {
				t = M_PI*(index[k]-xn);
				if (t == 0) 
					weights[k] = 1;
				else
					weights[k] = sin(t)/t;
					//weights[k] *= 0.5 + 0.5*cos((2*M_PI*(index[k]-xn))/s);
			}
			
			/* apply the mirror boundary conditions */
			for (k = 0; k < s; k++) {
				index[k] = (N_w == 1) ? (0) : ((index[k] < 0) ?
				(-index[k] - N_w2 * ((-index[k]) / N_w2))
				: (index[k] - N_w2 * (index[k] / N_w2)));
				if (N_w <= index[k]) {
					index[k] = N_w2 - index[k];
				}
			}
			
			for (j = 0; j < N_h; j++) { // iterate row-wise
				sum = 0;
				// interpolation
				for (k = 0; k < s; k++)
					sum += weights[k]*REAL(M)[index[k]*N_h + j];
				REAL(temp)[i*N_h + j] = sum;	
			}	
		}


		/***************************************
		***** interpolation in y-direction *****
		****************************************/

		z = ((double)N_h-1)/(h-1);
		for (j = 0; j < h; j++) { // iterate column-wise
			yn = z*j;  // new y-coordinate	
			/* compute the interpolation indexes */
			if (s & 1L) {
				m = (long)floor(yn + 0.5) - s/2L;
				for (k = 0; k < s; k++) 
					index[k] = m++;
			}
			else {
				m = (long)floor(yn) - s/2L + 1;
				for (k = 0; k < s; k++)
					index[k] = m++;
			}	
			
			/* compute the interpolation weights */
			for (k = 0; k < s; k++) {
				t = M_PI*(index[k]-yn);
				if (t == 0) 
					weights[k] = 1;
				else
					weights[k] = sin(t)/t;
					//weights[k] *= 0.5 + 0.5*cos((2*M_PI*(index[k]-xn))/s);
			}
			
			/* apply the mirror boundary conditions */
			for (k = 0; k < s; k++) {
				index[k] = (N_h == 1) ? (0) : ((index[k] < 0) ?
				(-index[k] - N_h2 * ((-index[k]) / N_h2))
				: (index[k] - N_h2 * (index[k] / N_h2)));
				if (N_h <= index[k]) {
					index[k] = N_h2 - index[k];
				}
			}
			
			for (i = 0; i < w; i++) { // iterate column-wise
				sum = 0;
				// interpolation
				for (k = 0; k < s; k++)
					sum += weights[k]*REAL(temp)[i*N_h + index[k]];
				REAL(res)[i*h + j] = sum;	
			}
		}		
		
		UNPROTECT(P);
		return res;
}
