#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>
#include <math.h>

/************ 
Split an integer matrix M into equally sized blocks
*************
For a matrix with R rows and C columns there are 
(R - ol_v)/(h_block - ol_v) * (C - ol_h)/(w_block - ol_h) 
blocks of dimension (h_block,w_block) with overlap 
(ol_v,ol_h).
*************
Examples:	

R=8, C=?, h_block=3, ol_v=1
(R - ol_v)/(h_block - ol_v) = 7/2 = 3

	b1	b2	b3
r1	|
r2	|
r3	|	|
r4		|
r5		|	|
r6			|
r7			|
r8


R=8, C=?, h_block=3, ol_v=-1
(R - ol_v)/(h_block - ol_v) = 9/4 = 2

	b1	b2
r1	|
r2	|
r3	|	
r4		
r5		|	
r6		|	
r7		|	
r8


*************/
SEXP block(SEXP M, SEXP dim_block, SEXP overlap)	{
		
		
		
	SEXP blocks, pos, names, dimnames_pos, result;
	SEXP null = R_NilValue;
	int i, j, rows, cols, h, w, ol_v, ol_h;
	int P = 0;	
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
		
	if (!isInteger(dim_block))
		error("block dimensions must be integer values");
		
	if (!isInteger(overlap))
		error("block overlap must be integer values");

		
	// number of rows and columns of M
	rows = INTEGER(getAttrib(M,R_DimSymbol))[0];
	cols = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	// height and width of the blocks
	h = INTEGER(dim_block)[0];
	w = INTEGER(dim_block)[1];
	
	if ((h < 1) || (w < 1))
		error("block dimensions must be greater than 0");
	
	if ((rows < h) || (cols < w))
		error("matrix dimensions must at least be equal to block dimensions");
		
	// block overlap in vertical and horizontal direction
	ol_v = INTEGER(overlap)[0];
	ol_h = INTEGER(overlap)[1]; 
	
	if ((ol_v > h) || (ol_h > w))
		error("blocks can't overlap by an amount larger than their own size");
	

	/*** allocate block and position matrix ***/
		
	// number of elements per block
	int n_block = w*h;
	// number of blocks in vertical and horizontal direction
	int N_block_v = (rows - ol_v)/(h - ol_v); 
	int N_block_h = (cols - ol_h)/(w - ol_h);
	if (N_block_v == 0) // ol_v = rows
		N_block_v = 1;
	if (N_block_h == 0) // ol_h = cols
		N_block_h = 1;
	// total number of blocks
	int N_block = N_block_v*N_block_h;
	PROTECT(blocks = allocMatrix(REALSXP, n_block, N_block)); P++;
	PROTECT(pos = allocMatrix(INTSXP, 2, N_block)); P++;
	
	/*** fill block matrix ***/
	
	for (i = 0; i < N_block; i++){ // iterate block matrix column-wise
		// calculate offset (absolut position of the top left block element)
		int o_1 = (i%N_block_v)*(h - ol_v);
		int o_2 = (i/N_block_v)*(w - ol_h);
		INTEGER(pos)[2*i] = o_1 + 1;
		INTEGER(pos)[2*i+1] = o_2 + 1;
		for (j = 0; j < n_block; j++){ // iterate block matrix row-wise
			// M[a,b] = M[rows*b + a]
			// blocks[i,j] = M[o_1 + j%h, o_2 + j/h]
			REAL(blocks)[i*n_block + j] = REAL(M)[(o_1 + j%h) + rows*(o_2 + j/h)]; 
		}
	}
	
	/*** compose returned list and attach names ***/

	// dimnames of the position matrix 
	SEXP dimnames_temp;
	PROTECT(dimnames_temp = allocVector(STRSXP,2)); P++;
	SET_STRING_ELT(dimnames_temp, 0, mkChar("row"));
	SET_STRING_ELT(dimnames_temp, 1, mkChar("col"));
	
	PROTECT(dimnames_pos = allocVector(VECSXP,2)); P++;
	SET_VECTOR_ELT(dimnames_pos, 0, dimnames_temp);
	SET_VECTOR_ELT(dimnames_pos, 1, null);
	
	setAttrib(pos, R_DimNamesSymbol, dimnames_pos);

	// names of the returned list elements
	PROTECT(names = allocVector(STRSXP,2)); P++;
	SET_STRING_ELT(names, 0, mkChar("blocks"));
	SET_STRING_ELT(names, 1, mkChar("positions"));
		
	// returned list
	PROTECT(result = allocVector(VECSXP,2)); P++;
	SET_VECTOR_ELT(result, 0, blocks);
	SET_VECTOR_ELT(result, 1, pos);
	
	setAttrib(result, R_NamesSymbol, names);

	
	UNPROTECT(P);
	
	return(result);								
}

