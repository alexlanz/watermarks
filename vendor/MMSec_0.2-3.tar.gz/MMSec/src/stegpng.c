// (w) 12/2003 Rainer Böhme <rb@reflex-studio.de>
// (c) Technische Universitaet Dresden

// 10/2004: added support for indexed PNGs <rb21>
//currently being modified by nils moh


#include <R.h>
#include <Rinternals.h>
#include <png.h>
#include "labels.h"
#include "stegtools.h"

#define PNG_BYTES_TO_CHECK 4
#define PNG_MAX_PAL_COLORS 256

void debugprintpngglobal(void);


struct
{ unsigned char * data;

  int dx;  //image width
  int dy;  //image heigth
  int grey;  //bool is greyscale
  int palette;  //bool is paletted

  struct
  { int numcol;
    int r[PNG_MAX_PAL_COLORS],
	g[PNG_MAX_PAL_COLORS],
	b[PNG_MAX_PAL_COLORS];
  } pal;

} png_global;

int png_do_read(char * fname)
{
  FILE * f;
  char check_buf[PNG_BYTES_TO_CHECK];

  png_structp png_ptr;
  png_infop info_ptr;
  png_bytep * row_pointer;
  unsigned char * p;

  int row;
  int bpp; // byte per pixel

  if (!(f = fopen(fname, "rb")))
    error("unable to open file %s",fname);

  if (fread(check_buf, 1, PNG_BYTES_TO_CHECK, f)!=PNG_BYTES_TO_CHECK)
  {
    fclose(f);
    error("error reading file %s",fname);
  }

  if (png_sig_cmp(check_buf, (png_size_t)0, PNG_BYTES_TO_CHECK))
  {
    fclose(f);
    error("%s is not a valid png file",fname);
  }

  if (!(png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL)))
  {
    fclose(f);
    error("problems while calling your system's png library");
  }

  if (!(info_ptr = png_create_info_struct(png_ptr)))
  {
    fclose(f);
    png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
    error("libpng error");
  }

  if (setjmp(png_jmpbuf(png_ptr)))
  {
    fclose(f);
    png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
    error("error while decoding png file %s",fname);
  }

  // Get & check image parameters

  png_init_io(png_ptr,f);
  png_set_sig_bytes(png_ptr, PNG_BYTES_TO_CHECK);

  png_read_png(png_ptr, info_ptr, PNG_TRANSFORM_STRIP_16 |      //strip 16 bit samples to 8 bit
                                  PNG_TRANSFORM_STRIP_ALPHA |   //throw away alpha channel
				  PNG_TRANSFORM_PACKING |      //expand any sample(1,2,4bit) to byte (8bit)
				  0,NULL);

  png_global.dx		= png_get_image_width(png_ptr,info_ptr);
  png_global.dy   	= png_get_image_height(png_ptr,info_ptr);
  png_global.grey	= png_get_color_type(png_ptr, info_ptr)==PNG_COLOR_TYPE_GRAY;
  png_global.palette 	= png_get_color_type(png_ptr, info_ptr)==PNG_COLOR_TYPE_PALETTE;

  // Check & read color palette

  if (png_global.palette)
  {
    png_color * pal;
    png_get_PLTE(png_ptr,info_ptr,&pal,&png_global.pal.numcol);

    if (png_global.pal.numcol<=PNG_MAX_PAL_COLORS)
    {
      int i;
      for (i=0;i<png_global.pal.numcol;i++)
      {
	png_global.pal.r[i] = pal[i].red;
	png_global.pal.g[i] = pal[i].green;
	png_global.pal.b[i] = pal[i].blue;
      }
   }
    else
     error("palette of png file %s has more than %i entries",fname,PNG_MAX_PAL_COLORS);
  }

  // Compute memory allocation and get heap space

  bpp = (png_global.grey||png_global.palette)?1:3;

  row_pointer = png_get_rows(png_ptr, info_ptr);

  p = png_global.data = R_alloc(png_global.dx * png_global.dy,bpp);

  for (row=0;row<png_global.dy;row++)
  {
    memcpy(p,row_pointer[row],png_global.dx*bpp);
    p+=png_global.dx * bpp;
  }

  fclose(f);
  png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);

  return 0;
}

// PNG Import Functions

SEXP png_read_rgb(SEXP file)
{ char * filename = CHAR(PROTECT(asChar(file)));
  SEXP ans, names, class, palette, pnames;
  SEXP red, green, blue, grey, map;
  int P = 1;

  int dx, dy, x, y, i, k, slot;
  unsigned char * p;

  png_do_read(filename);

  dx = png_global.dx;
  dy = png_global.dy;
  p  = png_global.data;

  PROTECT(class = allocVector(STRSXP,1)); P++;

  // store pixel data in matrices

  if (png_global.palette)
  {
    // class "indexmap"

    SET_STRING_ELT(class, 0, mkChar(LABEL_INDEXMAP));

    PROTECT(map = allocMatrix(INTSXP, dy, dx)); P++;
    for (y=0;y<dy;y++)
      for (x=0;x<dx;x++)
       INTEGER(map)[dy*x+y] = *(p++)+1;

    // create palette

    PROTECT(palette = allocVector(VECSXP,3)); P++;

    PROTECT(red=   allocVector(REALSXP, png_global.pal.numcol)); P++;
    PROTECT(green= allocVector(REALSXP, png_global.pal.numcol)); P++;
    PROTECT(blue=  allocVector(REALSXP, png_global.pal.numcol)); P++;

    for (y=0;y<png_global.pal.numcol;y++)
    {
      REAL(red)[y]   = ((double) png_global.pal.r[y])/255;
      REAL(green)[y] = ((double) png_global.pal.g[y])/255;
      REAL(blue)[y]  = ((double) png_global.pal.b[y])/255;
    }

    SET_VECTOR_ELT(palette, 0, red);
    SET_VECTOR_ELT(palette, 1, green);
    SET_VECTOR_ELT(palette, 2, blue);

    // define names for palette sub-structure

    PROTECT(pnames = allocVector(VECSXP,3)); P++;

    SET_VECTOR_ELT(pnames, 0, mkChar(LABEL_RED));
    SET_VECTOR_ELT(pnames, 1, mkChar(LABEL_GREEN));
    SET_VECTOR_ELT(pnames, 2, mkChar(LABEL_BLUE));

    setAttrib(palette, R_NamesSymbol, pnames);

    // create list for indexmap components

    PROTECT(ans= allocVector(VECSXP,3)); P++;

    SET_VECTOR_ELT(ans, 0, map);
    SET_VECTOR_ELT(ans, 1, palette);
    SET_VECTOR_ELT(ans, 2, file);

    // add element names

    PROTECT(names = allocVector(VECSXP,3)); P++;

    SET_VECTOR_ELT(names, 0, mkChar(LABEL_MAP));
    SET_VECTOR_ELT(names, 1, mkChar(LABEL_PALETTE));
    SET_VECTOR_ELT(names, 2, mkChar(LABEL_NAME));
  }

  else {  // no index map, hence either greymap or rgbmap

  if (png_global.grey)
  {
    // class "greymap"

    SET_STRING_ELT(class, 0, mkChar(LABEL_GREYMAP));

    PROTECT(grey = allocMatrix(REALSXP, dy, dx)); P++;
    for (y=0;y<dy;y++)
      for (x=0;x<dx;x++)
	REAL(grey)[dy*x+y] = ((double)*(p++))/255;

    // create list for grey matrix

    PROTECT(ans = allocVector(VECSXP,2)); P++;

    SET_VECTOR_ELT(ans, 0, grey);
    SET_VECTOR_ELT(ans, 1, file);

    // add element names

    PROTECT(names = allocVector(VECSXP,2)); P++;

    SET_VECTOR_ELT(names, 0, mkChar(LABEL_GREY));
    SET_VECTOR_ELT(names, 1, mkChar(LABEL_NAME));
  }
  else
  {
    // class "rgbmap"

    SET_STRING_ELT(class, 0, mkChar(LABEL_RGBMAP));

    PROTECT(red   = allocMatrix(REALSXP, dy, dx)); P++;
    PROTECT(green = allocMatrix(REALSXP, dy, dx)); P++;
    PROTECT(blue  = allocMatrix(REALSXP, dy, dx)); P++;

    for (y=0;y<dy;y++)
      for(x=0;x<dx;x++) {
	REAL(red)[dy*x+y]   = ((double)*(p++))/255;
	REAL(green)[dy*x+y] = ((double)*(p++))/255;
	REAL(blue)[dy*x+y]  = ((double)*(p++))/255;
      }

    // create list of red, green and blue matrices

    PROTECT(ans = allocVector(VECSXP,4)); P++;

    SET_VECTOR_ELT(ans, 0, red);
    SET_VECTOR_ELT(ans, 1, green);
    SET_VECTOR_ELT(ans, 2, blue);
    SET_VECTOR_ELT(ans, 3, file);

    // add element names

    PROTECT(names = allocVector(VECSXP,4)); P++;

    SET_VECTOR_ELT(names, 0, mkChar(LABEL_RED));
    SET_VECTOR_ELT(names, 1, mkChar(LABEL_GREEN));
    SET_VECTOR_ELT(names, 2, mkChar(LABEL_BLUE));

    SET_VECTOR_ELT(names, 3, mkChar(LABEL_NAME));
  }
  }

  setAttrib(ans, R_NamesSymbol, names);

  // set class

  classgets(ans,class);

  UNPROTECT(P);
  return ans;
}

//schreibt die daten aus der uebergebenen struktur in das pngglobal struct
// S_input ist greymap oder rgbmap oder indexmap
SEXP makePNGglobal(SEXP S_input,SEXP S_filename,SEXP S_overwrite)
 {char * filename = CHAR(PROTECT(asChar(S_filename)));
  char * attribut = "wink"; //"indexmap";
  int P=1;
  int line;
  int column;
  int palettesize;
  int i;
  unsigned char * p;
  SEXP S_palette,S_pal_red,S_pal_green,S_pal_blue;
  SEXP S_imagedata,S_map_red,S_map_blue,S_map_green;
  
  //int breite;
  //int hoehe;

  attribut = CHAR(PROTECT(asChar(getAttrib(S_input,R_ClassSymbol))));
  P++;
  //        TODO
  //printf("attribut: ...%s... \n",attribut);
  //printf("LABEL_INDEXMAP: ...%s... \n",LABEL_INDEXMAP);
  //attribut=LABEL_INDEXMAP;
  
  i=strcmp(attribut,LABEL_INDEXMAP);
  //printf("strcmp: %i \n",i);
  
/////////greymap//////////////////////////////////////////////////////////////
if (strcmp(attribut,LABEL_GREYMAP)) i=0;// cmp <> 0  
                               else i=1;// cmp = 0
if(i)
  {
   //printf("greymap found \n");
   
S_imagedata= getListElement(S_input,LABEL_GREY);

   png_global.grey=1;
   png_global.palette=0;
   
png_global.dx =INTEGER(getAttrib(S_imagedata,R_DimSymbol))[1]; //width !!
   png_global.dy =INTEGER(getAttrib(S_imagedata,R_DimSymbol))[0]; //height!


   png_global.data=(unsigned char *) malloc(png_global.dx*png_global.dy*sizeof(unsigned char));
   p=png_global.data; //arbeitszeiger

   //bildpunkte ins array schreiben
   for(line=0;line<png_global.dy;line++)  //height
     {
     //p=scanline;
     //printf("writing line\n");
     for(column=0;column<png_global.dx;column++)  //width
       {
       
(*p)=((unsigned char)
             ((255*REAL(S_imagedata)[png_global.dy*column+line])+0.5)
	     );
       //printf(" %u ",(*p));  /// MK 2009/10/26
       p++;
       }
     } //foreach line
  

}//ende greymap
///////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////// INDEXMAP //////////////////////////////////////////////
  if (strcmp(attribut,LABEL_INDEXMAP)) i=0;// cmp <> 0  
                                  else i=1;// cmp = 0
  if(i)
  {
   //printf("indexmap found \n");
   //get number of pal entries
   S_palette = getListElement(S_input,LABEL_PALETTE);

   S_pal_red  = getListElement(S_palette,LABEL_RED);
   S_pal_green= getListElement(S_palette,LABEL_GREEN);
   S_pal_blue = getListElement(S_palette,LABEL_BLUE);

   S_imagedata= getListElement(S_input,LABEL_MAP);

   png_global.grey=0;
   png_global.palette=1;
   png_global.pal.numcol=length(S_pal_red);
   png_global.dx =INTEGER(getAttrib(S_imagedata,R_DimSymbol))[1]; //width !!
   png_global.dy =INTEGER(getAttrib(S_imagedata,R_DimSymbol))[0]; //height!
   palettesize=png_global.pal.numcol;

   png_global.data=(unsigned char *) malloc(png_global.dx*png_global.dy*sizeof(unsigned char));
   p=png_global.data; //arbeitszeiger

   //bildpunkte ins array schreiben
   for(line=0;line<png_global.dy;line++)  //height
     {
     //p=scanline;
     //printf("writing line\n");
     for(column=0;column<png_global.dx;column++)  //width
       {
       //fillscanline
       (*p)=((unsigned char)INTEGER(S_imagedata)[png_global.dy*column+line])-1; //aenderung wg. indexmap
       //height*x+y
       //printf(" %u ",(*p));
       p++;
       }
     } //foreach line
  //palette schreiben:
  for (i=0;i<palettesize;i++)
    {
    png_global.pal.r[i]=(int) ((255*REAL(S_pal_red)[i])+0.5);
    png_global.pal.g[i]=(int) ((255*REAL(S_pal_green)[i])+0.5);
    png_global.pal.b[i]=(int) ((255*REAL(S_pal_blue)[i])+0.5);
    
    }


}//ende if indexmap
///////////////////////////////////////////////////////////////////////////////////////////
//////RGBMAP////////////////////////////////////////////////////////////////////7

if (strcmp(attribut,LABEL_RGBMAP)) i=0;// cmp <> 0  
                                  else i=1;// cmp = 0
  if(i)
  {
   //printf("rgbmap found \n");


   S_map_red  = getListElement(S_input,LABEL_RED);
   S_map_green= getListElement(S_input,LABEL_GREEN);
   S_map_blue = getListElement(S_input,LABEL_BLUE);

   //S_imagedata= getListElement(S_input,LABEL_MAP);

   png_global.grey=0;
   png_global.palette=0;
   
png_global.dx =INTEGER(getAttrib(S_map_red,R_DimSymbol))[1]; //width !!
   png_global.dy =INTEGER(getAttrib(S_map_red,R_DimSymbol))[0]; //height!


   png_global.data=(unsigned char *) malloc(png_global.dx*png_global.dy*3*sizeof(unsigned char));
   p=png_global.data; //arbeitszeiger

   //bildpunkte ins array schreiben
   for(line=0;line<png_global.dy;line++)  //height
     {
     //p=scanline;
     //printf("\n writing line\n");
     for(column=0;column<png_global.dx;column++)  //width
       {
       //fillscanline
       (*p)=((unsigned char)
             ((255*REAL(S_map_red)[png_global.dy*column+line])+0.5)
	    ); //aenderung wg. indexmap
       //height*x+y
       //printf("%u ",(*p));
       p++;
       (*p)=((unsigned char)
             ((255*REAL(S_map_green)[png_global.dy*column+line])+0.5)
	    );
       p++;
       (*p)=((unsigned char)
             ((255*REAL(S_map_blue)[png_global.dy*column+line])+0.5)
	    );
       p++;
       
       }
     } //foreach line
  


}//ende if rgbmap
writePNGglobal(filename,S_overwrite);

////ENDE RGBMAP/////////////////////////////////////////////////////////////////////////

  //debugprintpngglobal();
  
  free(png_global.data);
  UNPROTECT(P); 
  return(S_input);
 }

//gibt png_global mit printf aus
void debugprintpngglobal (void) 
{ //struct
  //{ unsigned char * data;

  // int dx;  //image width
  //int dy;  //image heigth
  //int grey;  //bool is greyscale
  //int palette;  //bool is paletted
  //
//  struct
//  { int numcol;
//    int r[PNG_MAX_PAL_COLORS],
//	g[PNG_MAX_PAL_COLORS],
//	b[PNG_MAX_PAL_COLORS];
//  } pal;

//
//} png_global;
printf("png_global.dx: %i \n"    ,png_global.dx);
printf("png_global.dy: %i \n"    ,png_global.dy);
printf("png_global.grey: %i\n"   ,png_global.grey);
printf("png_global.palette: %i\n",png_global.palette);

printf("png_global.pal.numcol: %i \n",png_global.pal.numcol);
printf("png_global.pal.r[0] %i \n",png_global.pal.r[0]);
printf("png_global.pal.g[0] %i \n",png_global.pal.g[0]);
printf("png_global.pal.b[0] %i \n",png_global.pal.b[0]);

}

////////////////////////////////////////////////////////////////
//schreibt den Inhalt von pngglobal in die datei <filename>
///////////////////////////////////////////////////////////////////


int writePNGglobal(char * filename, SEXP S_overwrite)
{ png_structp png_ptr;
  png_infop info_ptr;
  unsigned char * * rowpointerbase; //points to rowpointerarray of dynsize
  int pixelsize;
  int colt;
  int i;
  FILE * fp;
  png_colorp palette;
  
  check_overwrite(filename,S_overwrite);
  
  fp = fopen(filename, "wb");
    if (!fp)
    {
      printf("fopen failed! \n"); 
      return (1);
    }
   
   png_ptr = png_create_write_struct
       (PNG_LIBPNG_VER_STRING,NULL,NULL,NULL); 
       //(png_voidp) user_error_ptr,
        //user_error_fn, user_warning_fn);
    if (!png_ptr)
       return (1);

  info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr)
    {
       png_destroy_write_struct(&png_ptr,
(png_infopp) NULL);
       return (1);
    }

   if(setjmp(png_jmpbuf(png_ptr)))
   {
    //problems :-(
    fclose(fp);
    png_destroy_write_struct(&png_ptr,&info_ptr);
    return(1);
   }
   
   png_init_io(png_ptr,fp);
      
   //now the real image informations:
   if(png_global.palette) colt = PNG_COLOR_TYPE_PALETTE; //pngcolortype
   else if(png_global.grey) colt = PNG_COLOR_TYPE_GRAY; //pngcolortype
   else colt = PNG_COLOR_TYPE_RGB; //pngcolortype
   
   png_set_IHDR(png_ptr,info_ptr,png_global.dx,png_global.dy,8,colt,
        PNG_INTERLACE_NONE,PNG_COMPRESSION_TYPE_BASE,PNG_FILTER_TYPE_DEFAULT);
   
   //now palette if necessary:
   if(png_global.palette)
   {
   palette = (png_colorp) png_malloc (png_ptr , PNG_MAX_PALETTE_LENGTH * sizeof (png_color));       
   
   //pal fuellen:
   for (i=0;i<png_global.pal.numcol;i++)
   {
   
   palette[i].red   = png_global.pal.r[i];
   palette[i].green = png_global.pal.g[i];
   palette[i].blue  = png_global.pal.b[i];
   
   
   }
   
   //register pal to be written
   png_set_PLTE(png_ptr,info_ptr,palette,png_global.pal.numcol);//PNG_MAX_PALETTE_LENGTH);
   } //end palette
   
   png_write_info(png_ptr,info_ptr);
   
   rowpointerbase = (unsigned char * *) malloc(png_global.dy* sizeof (unsigned char *));
   
   pixelsize=3; //in bytes
   if(png_global.palette) pixelsize=1;
   if(png_global.grey) pixelsize=1;
   
   for(i=0;i<png_global.dy;i++) 
   {
   rowpointerbase[i] = &(png_global.data[i*png_global.dx*pixelsize]);
   //printf("rowp[%i] %i %u",i,rowpointerbase[i],rowpointerbase[i]);
   }
   
   png_write_image(png_ptr,rowpointerbase);
   
   png_write_end(png_ptr,info_ptr);
   
   if(png_global.palette) {png_free(png_ptr,palette); palette=NULL;}
   
   png_destroy_write_struct(&png_ptr,&info_ptr);
   
   free(rowpointerbase);
   
   fclose(fp);
  
  return(0);
}
