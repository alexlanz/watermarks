#include <R.h>
#include <Rmath.h>
#include <math.h>
#include <Rinternals.h>

#include	<stddef.h>
#include	<stdio.h>
#include	<stdlib.h>


/************************************

		B-SPLINE-TRANSFORM

************************************/


/************ 
Routines for B-spline transform
- initialCausalCoefficient
- initialAntiCausalCoefficient
- convertToCoefficients
*************
Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.
*************

The code is that of Philippe Th�venaz (january 3, 2006).
http://bigwww.epfl.ch/thevenaz/interpolation/
*************/ 


static double	initialCausalCoefficient
				(
					double	c[],		/* coefficients */
					int	DataLength,		/* number of coefficients */
					double	z,			/* actual pole */
					double Tolerance	
				)

{
	double	Sum, zn, z2n, iz;
	int	n, Horizon;
	
	/* this initialization corresponds to mirror boundaries */
	Horizon = DataLength;
	if (Tolerance > 0.0) {
		Horizon = (int)ceil(log(Tolerance) / log(fabs(z)));
	}
	if (Horizon < DataLength) {
		/* accelerated loop */
		zn = z;
		Sum = c[0];
		for (n = 1L; n < Horizon; n++) {
			Sum += zn * c[n];
			zn *= z;
		}
		return(Sum);
	}
	
	else{

	/* full loop */
	zn = z;
	iz = 1.0 / z;
	z2n = pow(z, (double)(DataLength - 1));
	Sum = c[0] + z2n * c[DataLength - 1];
	z2n *= z2n * iz;
	for (n = 1; n <= DataLength - 2; n++) {
		Sum += (zn + z2n) * c[n];
		zn *= z;
		z2n *= iz;
		}
	return(Sum / (1.0 - zn * zn));
	}
} 



static double	initialAntiCausalCoefficient
				(
					double	c[],		/* coefficients */
					int	DataLength,	/* number of samples or coefficients */
					double	z			/* actual pole */
				)

{ /* begin InitialAntiCausalCoefficient */

	/* this initialization corresponds to mirror boundaries */
	return((z / (z * z - 1.0)) * (z * c[DataLength - 2] + c[DataLength - 1]));
} /* end InitialAntiCausalCoefficient */




static void convertToCoefficients(double c[], int DataLength, double z[], int NbPoles, double Tolerance){

	double	Lambda = 1.0;
	int	n, k;

	/* special case required by mirror boundaries */
	if (DataLength == 1) {
//		return;
	}
	/* compute the overall gain */
	for (k = 0; k < NbPoles; k++) {
		Lambda = Lambda * (1.0 - z[k]) * (1.0 - 1.0 / z[k]);
	}
	/* apply the gain */
	for (n = 0; n < DataLength; n++) {
		c[n] *= Lambda;
	}
	
	/* loop over all poles */
	for (k = 0; k < NbPoles; k++) {
		// causal initialization
		c[0] = initialCausalCoefficient(c, DataLength, z[k], Tolerance);
		// causal recursion 
		for (n = 1; n < DataLength; n++) {
			c[n] += z[k] * c[n - 1];
		}
		
		// anticausal initialization 
		c[DataLength - 1] = initialAntiCausalCoefficient(c, DataLength, z[k]);
		// anticausal recursion 
		
		for (n = DataLength - 2; 0 <= n; n--) {
			c[n] = z[k] * (c[n + 1] - c[n]);
		}
	}
}




/************ 
Compute B-spline transformation coefficients
*************
Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.
*************

The code is a slightly adapted version of that of Philippe Th�venaz (january 3, 2006).
http://bigwww.epfl.ch/thevenaz/interpolation/
*************/ 
SEXP bspline_coefficients(SEXP M, SEXP spline_degree){

	SEXP res, temp;
	
	int SplineDegree, N_h, N_w;
	double *Line, *Liney;
	double Pole[4];
	int NbPoles;
	int x, y;
	
	int P = 0;
	
	SplineDegree = INTEGER(spline_degree)[0];
	
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	res = PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	temp = PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/* recover the poles from a lookup table */
	switch (SplineDegree) {
		case 2:
			NbPoles = 1;
			Pole[0] = sqrt(8.0) - 3.0;
			break;
		case 3:
			NbPoles = 1;
			Pole[0] = sqrt(3.0) - 2.0;
			break;
		case 4:
			NbPoles = 2;
			Pole[0] = sqrt(664.0 - sqrt(438976.0)) + sqrt(304.0) - 19.0;
			Pole[1] = sqrt(664.0 + sqrt(438976.0)) - sqrt(304.0) - 19.0;
			break;
		case 5:
			NbPoles = 2;
			Pole[0] = sqrt(135.0 / 2.0 - sqrt(17745.0 / 4.0)) + sqrt(105.0 / 4.0)
				- 13.0 / 2.0;
			Pole[1] = sqrt(135.0 / 2.0 + sqrt(17745.0 / 4.0)) - sqrt(105.0 / 4.0)
				- 13.0 / 2.0;
			break;
		case 6:
			NbPoles = 3;
			Pole[0] = -0.48829458930304475513011803888378906211227916123938;
			Pole[1] = -0.081679271076237512597937765737059080653379610398148;
			Pole[2] = -0.0014141518083258177510872439765585925278641690553467;
			break;
		case 7:
			NbPoles = 3;
			Pole[0] = -0.53528043079643816554240378168164607183392315234269;
			Pole[1] = -0.12255461519232669051527226435935734360548654942730;
			Pole[2] = -0.0091486948096082769285930216516478534156925639545994;
			break;
		case 8:
			NbPoles = 4;
			Pole[0] = -0.57468690924876543053013930412874542429066157804125;
			Pole[1] = -0.16303526929728093524055189686073705223476814550830;
			Pole[2] = -0.023632294694844850023403919296361320612665920854629;
			Pole[3] = -0.00015382131064169091173935253018402160762964054070043;
			break;
		case 9:
			NbPoles = 4;
			Pole[0] = -0.60799738916862577900772082395428976943963471853991;
			Pole[1] = -0.20175052019315323879606468505597043468089886575747;
			Pole[2] = -0.043222608540481752133321142979429688265852380231497;
			Pole[3] = -0.0021213069031808184203048965578486234220548560988624;
			break;
		default:
			error("Invalid spline degree\n");
	}

	Line = (double *)Calloc(N_w, double);
	
	// x direction
	
	for (y = 0; y < N_h; y++){
		// read image row-wise
		for (x = 0; x < N_w; x++)
			Line[x] = REAL(M)[x*N_h + y];
		// B-Spline transform
		convertToCoefficients(Line,N_w,Pole,NbPoles, DBL_EPSILON);
		// write interpolation coefficients
		for (x = 0; x < N_w; x++)
			REAL(res)[x*N_h + y] = Line[x];
	}

	Free(Line);
	Line = (double *)Calloc(N_h, double);
	
	// y direction
	
	for (x = 0; x < N_w; x++){
		// read image column-wise
		for (y = 0; y < N_h; y++)
			Line[y] = REAL(res)[x*N_h + y];
		// B-Spline transform
		convertToCoefficients(Line,N_h,Pole,NbPoles, DBL_EPSILON);
		// write interpolation coefficients
		for (y = 0; y < N_h; y++)
			REAL(res)[x*N_h + y] = Line[y];
	}
	
	Free(Line);

	UNPROTECT(P);
	
	return res;


}





/************************************

		B-SPLINE-INTERPOLATION

************************************/



/************ 
Routine for B-spline interpolation
*************
Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.
*************

The code is a slightly adapted version of that of Philippe Th�venaz (january 3, 2006).
http://bigwww.epfl.ch/thevenaz/interpolation/
*************/ 
extern double	InterpolatedValue
				(
					SEXP	Bcoeff,		/* input B-spline array of coefficients */
					long	Width,		/* width of the image */
					long	Height,		/* height of the image */
					double	x,			/* x coordinate where to interpolate */
					double	y,			/* y coordinate where to interpolate */
					long	SplineDegree/* degree of the spline model */
				)

{ /* begin InterpolatedValue */

	float	*p;
	double	xWeight[10], yWeight[10];
	double	interpolated;
	double	w, w2, w4, t, t0, t1;
	long	xIndex[10], yIndex[10];
	long	Width2 = 2L * Width - 2L, Height2 = 2L * Height - 2L;
	long	i, j, k;

	/* compute the interpolation indexes */
	if (SplineDegree & 1L) {
		i = (long)floor(x) - SplineDegree / 2L;
		//Rprintf("%4f,",x);
		j = (long)floor(y) - SplineDegree / 2L;
		for (k = 0L; k <= SplineDegree; k++) {
			xIndex[k] = i++;
			yIndex[k] = j++;
		}
	}
	else {
		i = (long)floor(x + 0.5) - SplineDegree / 2L;
		j = (long)floor(y + 0.5) - SplineDegree / 2L;
		for (k = 0L; k <= SplineDegree; k++) {
			xIndex[k] = i++;
			yIndex[k] = j++;
		}
	}

	/* compute the interpolation weights */
	switch (SplineDegree) {
		case 1L:
			/* x */
			w = x - (double)xIndex[0];
			xWeight[1] = w;
			xWeight[0] = 1-w;
			
			/* y */
			w = y - (double)yIndex[0];
			yWeight[1] = w;
			yWeight[0] = 1-w;
			break;
		case 2L:
			/* x */
			w = x - (double)xIndex[1];
			xWeight[1] = 3.0 / 4.0 - w * w;
			xWeight[2] = (1.0 / 2.0) * (w - xWeight[1] + 1.0);
			xWeight[0] = 1.0 - xWeight[1] - xWeight[2];
			/* y */
			w = y - (double)yIndex[1];
			yWeight[1] = 3.0 / 4.0 - w * w;
			yWeight[2] = (1.0 / 2.0) * (w - yWeight[1] + 1.0);
			yWeight[0] = 1.0 - yWeight[1] - yWeight[2];
			break;
		case 3L:
			/* x */
			w = x - (double)xIndex[1];
			xWeight[3] = (1.0 / 6.0) * w * w * w;
			xWeight[0] = (1.0 / 6.0) + (1.0 / 2.0) * w * (w - 1.0) - xWeight[3];
			xWeight[2] = w + xWeight[0] - 2.0 * xWeight[3];
			xWeight[1] = 1.0 - xWeight[0] - xWeight[2] - xWeight[3];
			/* y */
			w = y - (double)yIndex[1];
			yWeight[3] = (1.0 / 6.0) * w * w * w;
			yWeight[0] = (1.0 / 6.0) + (1.0 / 2.0) * w * (w - 1.0) - yWeight[3];
			yWeight[2] = w + yWeight[0] - 2.0 * yWeight[3];
			yWeight[1] = 1.0 - yWeight[0] - yWeight[2] - yWeight[3];
			break;
		case 4L:
			/* x */
			w = x - (double)xIndex[2];
			w2 = w * w;
			t = (1.0 / 6.0) * w2;
			xWeight[0] = 1.0 / 2.0 - w;
			xWeight[0] *= xWeight[0];
			xWeight[0] *= (1.0 / 24.0) * xWeight[0];
			t0 = w * (t - 11.0 / 24.0);
			t1 = 19.0 / 96.0 + w2 * (1.0 / 4.0 - t);
			xWeight[1] = t1 + t0;
			xWeight[3] = t1 - t0;
			xWeight[4] = xWeight[0] + t0 + (1.0 / 2.0) * w;
			xWeight[2] = 1.0 - xWeight[0] - xWeight[1] - xWeight[3] - xWeight[4];
			/* y */
			w = y - (double)yIndex[2];
			w2 = w * w;
			t = (1.0 / 6.0) * w2;
			yWeight[0] = 1.0 / 2.0 - w;
			yWeight[0] *= yWeight[0];
			yWeight[0] *= (1.0 / 24.0) * yWeight[0];
			t0 = w * (t - 11.0 / 24.0);
			t1 = 19.0 / 96.0 + w2 * (1.0 / 4.0 - t);
			yWeight[1] = t1 + t0;
			yWeight[3] = t1 - t0;
			yWeight[4] = yWeight[0] + t0 + (1.0 / 2.0) * w;
			yWeight[2] = 1.0 - yWeight[0] - yWeight[1] - yWeight[3] - yWeight[4];
			break;
		case 5L:
			/* x */
			w = x - (double)xIndex[2];
			w2 = w * w;
			xWeight[5] = (1.0 / 120.0) * w * w2 * w2;
			w2 -= w;
			w4 = w2 * w2;
			w -= 1.0 / 2.0;
			t = w2 * (w2 - 3.0);
			xWeight[0] = (1.0 / 24.0) * (1.0 / 5.0 + w2 + w4) - xWeight[5];
			t0 = (1.0 / 24.0) * (w2 * (w2 - 5.0) + 46.0 / 5.0);
			t1 = (-1.0 / 12.0) * w * (t + 4.0);
			xWeight[2] = t0 + t1;
			xWeight[3] = t0 - t1;
			t0 = (1.0 / 16.0) * (9.0 / 5.0 - t);
			t1 = (1.0 / 24.0) * w * (w4 - w2 - 5.0);
			xWeight[1] = t0 + t1;
			xWeight[4] = t0 - t1;
			/* y */
			w = y - (double)yIndex[2];
			w2 = w * w;
			yWeight[5] = (1.0 / 120.0) * w * w2 * w2;
			w2 -= w;
			w4 = w2 * w2;
			w -= 1.0 / 2.0;
			t = w2 * (w2 - 3.0);
			yWeight[0] = (1.0 / 24.0) * (1.0 / 5.0 + w2 + w4) - yWeight[5];
			t0 = (1.0 / 24.0) * (w2 * (w2 - 5.0) + 46.0 / 5.0);
			t1 = (-1.0 / 12.0) * w * (t + 4.0);
			yWeight[2] = t0 + t1;
			yWeight[3] = t0 - t1;
			t0 = (1.0 / 16.0) * (9.0 / 5.0 - t);
			t1 = (1.0 / 24.0) * w * (w4 - w2 - 5.0);
			yWeight[1] = t0 + t1;
			yWeight[4] = t0 - t1;
			break;
		case 6L:
			/* x */
			w = x - (double)xIndex[3];
			xWeight[0] = 1.0 / 2.0 - w;
			xWeight[0] *= xWeight[0] * xWeight[0];
			xWeight[0] *= xWeight[0] / 720.0;
			xWeight[1] = (361.0 / 192.0 - w * (59.0 / 8.0 + w
				* (-185.0 / 16.0 + w * (25.0 / 3.0 + w * (-5.0 / 2.0 + w)
				* (1.0 / 2.0 + w))))) / 120.0;
			xWeight[2] = (10543.0 / 960.0 + w * (-289.0 / 16.0 + w
				* (79.0 / 16.0 + w * (43.0 / 6.0 + w * (-17.0 / 4.0 + w
				* (-1.0 + w)))))) / 48.0;
			w2 = w * w;
			xWeight[3] = (5887.0 / 320.0 - w2 * (231.0 / 16.0 - w2
				* (21.0 / 4.0 - w2))) / 36.0;
			xWeight[4] = (10543.0 / 960.0 + w * (289.0 / 16.0 + w
				* (79.0 / 16.0 + w * (-43.0 / 6.0 + w * (-17.0 / 4.0 + w
				* (1.0 + w)))))) / 48.0;
			xWeight[6] = 1.0 / 2.0 + w;
			xWeight[6] *= xWeight[6] * xWeight[6];
			xWeight[6] *= xWeight[6] / 720.0;
			xWeight[5] = 1.0 - xWeight[0] - xWeight[1] - xWeight[2] - xWeight[3]
				- xWeight[4] - xWeight[6];
			/* y */
			w = y - (double)yIndex[3];
			yWeight[0] = 1.0 / 2.0 - w;
			yWeight[0] *= yWeight[0] * yWeight[0];
			yWeight[0] *= yWeight[0] / 720.0;
			yWeight[1] = (361.0 / 192.0 - w * (59.0 / 8.0 + w
				* (-185.0 / 16.0 + w * (25.0 / 3.0 + w * (-5.0 / 2.0 + w)
				* (1.0 / 2.0 + w))))) / 120.0;
			yWeight[2] = (10543.0 / 960.0 + w * (-289.0 / 16.0 + w
				* (79.0 / 16.0 + w * (43.0 / 6.0 + w * (-17.0 / 4.0 + w
				* (-1.0 + w)))))) / 48.0;
			w2 = w * w;
			yWeight[3] = (5887.0 / 320.0 - w2 * (231.0 / 16.0 - w2
				* (21.0 / 4.0 - w2))) / 36.0;
			yWeight[4] = (10543.0 / 960.0 + w * (289.0 / 16.0 + w
				* (79.0 / 16.0 + w * (-43.0 / 6.0 + w * (-17.0 / 4.0 + w
				* (1.0 + w)))))) / 48.0;
			yWeight[6] = 1.0 / 2.0 + w;
			yWeight[6] *= yWeight[6] * yWeight[6];
			yWeight[6] *= yWeight[6] / 720.0;
			yWeight[5] = 1.0 - yWeight[0] - yWeight[1] - yWeight[2] - yWeight[3]
				- yWeight[4] - yWeight[6];
			break;
		case 7L:
			/* x */
			w = x - (double)xIndex[3];
			xWeight[0] = 1.0 - w;
			xWeight[0] *= xWeight[0];
			xWeight[0] *= xWeight[0] * xWeight[0];
			xWeight[0] *= (1.0 - w) / 5040.0;
			w2 = w * w;
			xWeight[1] = (120.0 / 7.0 + w * (-56.0 + w * (72.0 + w
				* (-40.0 + w2 * (12.0 + w * (-6.0 + w)))))) / 720.0;
			xWeight[2] = (397.0 / 7.0 - w * (245.0 / 3.0 + w * (-15.0 + w
				* (-95.0 / 3.0 + w * (15.0 + w * (5.0 + w
				* (-5.0 + w))))))) / 240.0;
			xWeight[3] = (2416.0 / 35.0 + w2 * (-48.0 + w2 * (16.0 + w2
				* (-4.0 + w)))) / 144.0;
			xWeight[4] = (1191.0 / 35.0 - w * (-49.0 + w * (-9.0 + w
				* (19.0 + w * (-3.0 + w) * (-3.0 + w2))))) / 144.0;
			xWeight[5] = (40.0 / 7.0 + w * (56.0 / 3.0 + w * (24.0 + w
				* (40.0 / 3.0 + w2 * (-4.0 + w * (-2.0 + w)))))) / 240.0;
			xWeight[7] = w2;
			xWeight[7] *= xWeight[7] * xWeight[7];
			xWeight[7] *= w / 5040.0;
			xWeight[6] = 1.0 - xWeight[0] - xWeight[1] - xWeight[2] - xWeight[3]
				- xWeight[4] - xWeight[5] - xWeight[7];
			/* y */
			w = y - (double)yIndex[3];
			yWeight[0] = 1.0 - w;
			yWeight[0] *= yWeight[0];
			yWeight[0] *= yWeight[0] * yWeight[0];
			yWeight[0] *= (1.0 - w) / 5040.0;
			w2 = w * w;
			yWeight[1] = (120.0 / 7.0 + w * (-56.0 + w * (72.0 + w
				* (-40.0 + w2 * (12.0 + w * (-6.0 + w)))))) / 720.0;
			yWeight[2] = (397.0 / 7.0 - w * (245.0 / 3.0 + w * (-15.0 + w
				* (-95.0 / 3.0 + w * (15.0 + w * (5.0 + w
				* (-5.0 + w))))))) / 240.0;
			yWeight[3] = (2416.0 / 35.0 + w2 * (-48.0 + w2 * (16.0 + w2
				* (-4.0 + w)))) / 144.0;
			yWeight[4] = (1191.0 / 35.0 - w * (-49.0 + w * (-9.0 + w
				* (19.0 + w * (-3.0 + w) * (-3.0 + w2))))) / 144.0;
			yWeight[5] = (40.0 / 7.0 + w * (56.0 / 3.0 + w * (24.0 + w
				* (40.0 / 3.0 + w2 * (-4.0 + w * (-2.0 + w)))))) / 240.0;
			yWeight[7] = w2;
			yWeight[7] *= yWeight[7] * yWeight[7];
			yWeight[7] *= w / 5040.0;
			yWeight[6] = 1.0 - yWeight[0] - yWeight[1] - yWeight[2] - yWeight[3]
				- yWeight[4] - yWeight[5] - yWeight[7];
			break;
		case 8L:
			/* x */
			w = x - (double)xIndex[4];
			xWeight[0] = 1.0 / 2.0 - w;
			xWeight[0] *= xWeight[0];
			xWeight[0] *= xWeight[0];
			xWeight[0] *= xWeight[0] / 40320.0;
			w2 = w * w;
			xWeight[1] = (39.0 / 16.0 - w * (6.0 + w * (-9.0 / 2.0 + w2)))
				* (21.0 / 16.0 + w * (-15.0 / 4.0 + w * (9.0 / 2.0 + w
				* (-3.0 + w)))) / 5040.0;
			xWeight[2] = (82903.0 / 1792.0 + w * (-4177.0 / 32.0 + w
				* (2275.0 / 16.0 + w * (-487.0 / 8.0 + w * (-85.0 / 8.0 + w
				* (41.0 / 2.0 + w * (-5.0 + w * (-2.0 + w)))))))) / 1440.0;
			xWeight[3] = (310661.0 / 1792.0 - w * (14219.0 / 64.0 + w
				* (-199.0 / 8.0 + w * (-1327.0 / 16.0 + w * (245.0 / 8.0 + w
				* (53.0 / 4.0 + w * (-8.0 + w * (-1.0 + w)))))))) / 720.0;
			xWeight[4] = (2337507.0 / 8960.0 + w2 * (-2601.0 / 16.0 + w2
				* (387.0 / 8.0 + w2 * (-9.0 + w2)))) / 576.0;
			xWeight[5] = (310661.0 / 1792.0 - w * (-14219.0 / 64.0 + w
				* (-199.0 / 8.0 + w * (1327.0 / 16.0 + w * (245.0 / 8.0 + w
				* (-53.0 / 4.0 + w * (-8.0 + w * (1.0 + w)))))))) / 720.0;
			xWeight[7] = (39.0 / 16.0 - w * (-6.0 + w * (-9.0 / 2.0 + w2)))
				* (21.0 / 16.0 + w * (15.0 / 4.0 + w * (9.0 / 2.0 + w
				* (3.0 + w)))) / 5040.0;
			xWeight[8] = 1.0 / 2.0 + w;
			xWeight[8] *= xWeight[8];
			xWeight[8] *= xWeight[8];
			xWeight[8] *= xWeight[8] / 40320.0;
			xWeight[6] = 1.0 - xWeight[0] - xWeight[1] - xWeight[2] - xWeight[3]
				- xWeight[4] - xWeight[5] - xWeight[7] - xWeight[8];
			/* y */
			w = y - (double)yIndex[4];
			yWeight[0] = 1.0 / 2.0 - w;
			yWeight[0] *= yWeight[0];
			yWeight[0] *= yWeight[0];
			yWeight[0] *= yWeight[0] / 40320.0;
			w2 = w * w;
			yWeight[1] = (39.0 / 16.0 - w * (6.0 + w * (-9.0 / 2.0 + w2)))
				* (21.0 / 16.0 + w * (-15.0 / 4.0 + w * (9.0 / 2.0 + w
				* (-3.0 + w)))) / 5040.0;
			yWeight[2] = (82903.0 / 1792.0 + w * (-4177.0 / 32.0 + w
				* (2275.0 / 16.0 + w * (-487.0 / 8.0 + w * (-85.0 / 8.0 + w
				* (41.0 / 2.0 + w * (-5.0 + w * (-2.0 + w)))))))) / 1440.0;
			yWeight[3] = (310661.0 / 1792.0 - w * (14219.0 / 64.0 + w
				* (-199.0 / 8.0 + w * (-1327.0 / 16.0 + w * (245.0 / 8.0 + w
				* (53.0 / 4.0 + w * (-8.0 + w * (-1.0 + w)))))))) / 720.0;
			yWeight[4] = (2337507.0 / 8960.0 + w2 * (-2601.0 / 16.0 + w2
				* (387.0 / 8.0 + w2 * (-9.0 + w2)))) / 576.0;
			yWeight[5] = (310661.0 / 1792.0 - w * (-14219.0 / 64.0 + w
				* (-199.0 / 8.0 + w * (1327.0 / 16.0 + w * (245.0 / 8.0 + w
				* (-53.0 / 4.0 + w * (-8.0 + w * (1.0 + w)))))))) / 720.0;
			yWeight[7] = (39.0 / 16.0 - w * (-6.0 + w * (-9.0 / 2.0 + w2)))
				* (21.0 / 16.0 + w * (15.0 / 4.0 + w * (9.0 / 2.0 + w
				* (3.0 + w)))) / 5040.0;
			yWeight[8] = 1.0 / 2.0 + w;
			yWeight[8] *= yWeight[8];
			yWeight[8] *= yWeight[8];
			yWeight[8] *= yWeight[8] / 40320.0;
			yWeight[6] = 1.0 - yWeight[0] - yWeight[1] - yWeight[2] - yWeight[3]
				- yWeight[4] - yWeight[5] - yWeight[7] - yWeight[8];
			break;
		case 9L:
			/* x */
			w = x - (double)xIndex[4];
			xWeight[0] = 1.0 - w;
			xWeight[0] *= xWeight[0];
			xWeight[0] *= xWeight[0];
			xWeight[0] *= xWeight[0] * (1.0 - w) / 362880.0;
			xWeight[1] = (502.0 / 9.0 + w * (-246.0 + w * (472.0 + w
				* (-504.0 + w * (308.0 + w * (-84.0 + w * (-56.0 / 3.0 + w
				* (24.0 + w * (-8.0 + w))))))))) / 40320.0;
			xWeight[2] = (3652.0 / 9.0 - w * (2023.0 / 2.0 + w * (-952.0 + w
				* (938.0 / 3.0 + w * (112.0 + w * (-119.0 + w * (56.0 / 3.0 + w
				* (14.0 + w * (-7.0 + w))))))))) / 10080.0;
			xWeight[3] = (44117.0 / 42.0 + w * (-2427.0 / 2.0 + w * (66.0 + w
				* (434.0 + w * (-129.0 + w * (-69.0 + w * (34.0 + w * (6.0 + w
				* (-6.0 + w))))))))) / 4320.0;
			w2 = w * w;
			xWeight[4] = (78095.0 / 63.0 - w2 * (700.0 + w2 * (-190.0 + w2
				* (100.0 / 3.0 + w2 * (-5.0 + w))))) / 2880.0;
			xWeight[5] = (44117.0 / 63.0 + w * (809.0 + w * (44.0 + w
				* (-868.0 / 3.0 + w * (-86.0 + w * (46.0 + w * (68.0 / 3.0 + w
				* (-4.0 + w * (-4.0 + w))))))))) / 2880.0;
			xWeight[6] = (3652.0 / 21.0 - w * (-867.0 / 2.0 + w * (-408.0 + w
				* (-134.0 + w * (48.0 + w * (51.0 + w * (-4.0 + w) * (-1.0 + w)
				* (2.0 + w))))))) / 4320.0;
			xWeight[7] = (251.0 / 18.0 + w * (123.0 / 2.0 + w * (118.0 + w
				* (126.0 + w * (77.0 + w * (21.0 + w * (-14.0 / 3.0 + w
				* (-6.0 + w * (-2.0 + w))))))))) / 10080.0;
			xWeight[9] = w2 * w2;
			xWeight[9] *= xWeight[9] * w / 362880.0;
			xWeight[8] = 1.0 - xWeight[0] - xWeight[1] - xWeight[2] - xWeight[3]
				- xWeight[4] - xWeight[5] - xWeight[6] - xWeight[7] - xWeight[9];
			/* y */
			w = y - (double)yIndex[4];
			yWeight[0] = 1.0 - w;
			yWeight[0] *= yWeight[0];
			yWeight[0] *= yWeight[0];
			yWeight[0] *= yWeight[0] * (1.0 - w) / 362880.0;
			yWeight[1] = (502.0 / 9.0 + w * (-246.0 + w * (472.0 + w
				* (-504.0 + w * (308.0 + w * (-84.0 + w * (-56.0 / 3.0 + w
				* (24.0 + w * (-8.0 + w))))))))) / 40320.0;
			yWeight[2] = (3652.0 / 9.0 - w * (2023.0 / 2.0 + w * (-952.0 + w
				* (938.0 / 3.0 + w * (112.0 + w * (-119.0 + w * (56.0 / 3.0 + w
				* (14.0 + w * (-7.0 + w))))))))) / 10080.0;
			yWeight[3] = (44117.0 / 42.0 + w * (-2427.0 / 2.0 + w * (66.0 + w
				* (434.0 + w * (-129.0 + w * (-69.0 + w * (34.0 + w * (6.0 + w
				* (-6.0 + w))))))))) / 4320.0;
			w2 = w * w;
			yWeight[4] = (78095.0 / 63.0 - w2 * (700.0 + w2 * (-190.0 + w2
				* (100.0 / 3.0 + w2 * (-5.0 + w))))) / 2880.0;
			yWeight[5] = (44117.0 / 63.0 + w * (809.0 + w * (44.0 + w
				* (-868.0 / 3.0 + w * (-86.0 + w * (46.0 + w * (68.0 / 3.0 + w
				* (-4.0 + w * (-4.0 + w))))))))) / 2880.0;
			yWeight[6] = (3652.0 / 21.0 - w * (-867.0 / 2.0 + w * (-408.0 + w
				* (-134.0 + w * (48.0 + w * (51.0 + w * (-4.0 + w) * (-1.0 + w)
				* (2.0 + w))))))) / 4320.0;
			yWeight[7] = (251.0 / 18.0 + w * (123.0 / 2.0 + w * (118.0 + w
				* (126.0 + w * (77.0 + w * (21.0 + w * (-14.0 / 3.0 + w
				* (-6.0 + w * (-2.0 + w))))))))) / 10080.0;
			yWeight[9] = w2 * w2;
			yWeight[9] *= yWeight[9] * w / 362880.0;
			yWeight[8] = 1.0 - yWeight[0] - yWeight[1] - yWeight[2] - yWeight[3]
				- yWeight[4] - yWeight[5] - yWeight[6] - yWeight[7] - yWeight[9];
			break;
		default:
			printf("Invalid spline degree\n");
			return(0.0);
	}

	/* apply the mirror boundary conditions */
	for (k = 0L; k <= SplineDegree; k++) {
		xIndex[k] = (Width == 1L) ? (0L) : ((xIndex[k] < 0L) ?
			(-xIndex[k] - Width2 * ((-xIndex[k]) / Width2))
			: (xIndex[k] - Width2 * (xIndex[k] / Width2)));
		if (Width <= xIndex[k]) {
			xIndex[k] = Width2 - xIndex[k];
		}
		yIndex[k] = (Height == 1L) ? (0L) : ((yIndex[k] < 0L) ?
			(-yIndex[k] - Height2 * ((-yIndex[k]) / Height2))
			: (yIndex[k] - Height2 * (yIndex[k] / Height2)));
		if (Height <= yIndex[k]) {
			yIndex[k] = Height2 - yIndex[k];
		}
	}

	/* perform interpolation */
	interpolated = 0.0;
	for (j = 0L; j <= SplineDegree; j++) {
		//p = Bcoeff + (ptrdiff_t)(yIndex[j] * Width);
		w = 0.0;
		for (i = 0L; i <= SplineDegree; i++) {
			//w += xWeight[i] * p[xIndex[i]];
			w += xWeight[i] * REAL(Bcoeff)[xIndex[i]*Height + yIndex[j]]; 
		}
		interpolated += yWeight[j] * w;
	}

	return(interpolated);
} /* end InterpolatedValue */



/************ 
Scale a 2D-signal and interpolate with B-splines.
Apply naive geometric distortions to hide traces of resampling.

*************
Tamper Hiding: Defeating Image Forensics
Matthias Kirchner, Rainer B�hme.
Proceedings of the 9th Information Hiding Workshop, 2007.

Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.

*************
M				input matrix
coeff		B-spline coefficient matrix
dim			dimension vector of the resized image
degree	B-spline degree
r				strength of applied geometric distortion (standard deviation) 
*************/
SEXP scale_b(SEXP M, SEXP coeff, SEXP dim, SEXP degree, SEXP r){

	SEXP res;
	
	int h, w, N_h, N_w, i, j, SplineDegree;
	int P = 0;
	
	double z,x1,y1,rand,a11,a12,a21,a22;
	
	rand = REAL(r)[0];
	
	h = INTEGER(dim)[0];
	w = INTEGER(dim)[1];
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	SplineDegree = INTEGER(degree)[0];
	
	PROTECT(res = allocMatrix(REALSXP, h, w));
	P++;
	
	
	// interpolation positions in x and y direction
	double x[w], y[h];
	
	a11 = ((double)N_w-1)/(w-1);
	a22 = ((double)N_h-1)/(h-1);
	a12 = 0;
	a21 = 0;

	GetRNGstate();
		
	z = ((double)N_w-1)/(w-1);
	for (i = 0; i < w; i++){
		x[i] = z*i;
		}
	z = ((double)N_h-1)/(h-1);
	for (i = 0; i < h; i++){
		y[i] = z*i;
		}
	


	// perform interpolation
	for (i = 0; i < w; i++){
		for (j = 0; j < h; j++){
			
			x1 = x[i] + rnorm(0,rand);
			y1 = y[j] + rnorm(0,rand);
			
			REAL(res)[i*h + j] = InterpolatedValue(coeff, N_w, N_h, x1, y1, SplineDegree);
		 } 
	}
	
	UNPROTECT(P);
	
	PutRNGstate();
	
	return(res);
}


// exakte Angabe von omega, Bilddimension bleibt erhalten
SEXP scale_bw(SEXP M, SEXP coeff, SEXP omega, SEXP degree, SEXP r){

	SEXP res;
	
	int h, N_h, N_w, i, j, SplineDegree;
	int P = 0;
	double w;
	
	double z,x1,y1,rand;
	
	rand = REAL(r)[0];
	
	w = REAL(omega)[0];
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	SplineDegree = INTEGER(degree)[0];
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	
	// interpolation positions in x and y direction
	double x[N_w], y[N_h];
	

	GetRNGstate();
		
	for (i = 0; i < N_w; i++)
		x[i] = w*i;
	for (i = 0; i < N_h; i++)
		y[i] = w*i;


	// perform interpolation
	for (i = 0; i < N_w; i++){
		for (j = 0; j < N_h; j++){
			
			x1 = x[i] + rnorm(0,rand);
			y1 = y[j] + rnorm(0,rand);
			
			if ((x1 >= 0) && (x1 <= (N_w-1)) && (y1 >= 0) && (y1 <= (N_h-1)))
				REAL(res)[i*N_h + j] = InterpolatedValue(coeff, N_w, N_h, x1, y1, SplineDegree);
			else 
				REAL(res)[i*N_h + j] = 255;
		 } 
	}	
	UNPROTECT(P);
	PutRNGstate();

	return(res);
}


/************ 
Scale a 2D-signal and interpolate with B-splines.
Apply signal adaptive geometric distortions to hide traces of resampling.

*************
Tamper Hiding: Defeating Image Forensics
Matthias Kirchner, Rainer B�hme.
Proceedings of the 9th Information Hiding Workshop, 2007.

Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.

*************
M			input matrix
coeff		B-spline coefficient matrix
dim			dimension vector of the resized image
degree		B-spline degree
r			strength of applied geometric distortion (standard deviation) 
sobelh		result of a horizontal edge detector (applied on the already scaled image)
sobelv		result of a vertical edge detector (applied on the already scaled image)
*************/
SEXP scale_b2(SEXP M, SEXP coeff, SEXP dim, SEXP degree, SEXP r, 
							SEXP sobelh, SEXP sobelv){

	SEXP res;
	
	int h, w, N_h, N_w, i, j, SplineDegree;
	int P = 0;
	
	double z,x1,y1,rand,a11,a12,a21,a22;
	
	rand = REAL(r)[0];
	
	h = INTEGER(dim)[0];
	w = INTEGER(dim)[1];
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	SplineDegree = INTEGER(degree)[0];
	
	PROTECT(res = allocMatrix(REALSXP, h, w));
	P++;
	
	
	// interpolation positions in x and y direction
	double x[w], y[h];
	
	a11 = ((double)N_w-1)/(w-1);
	a22 = ((double)N_h-1)/(h-1);
	a12 = 0;
	a21 = 0;

	GetRNGstate();
		
	z = ((double)N_w-1)/(w-1);
	for (i = 0; i < w; i++){
		x[i] = z*i;
		}
	z = ((double)N_h-1)/(h-1);
	for (i = 0; i < h; i++){
		y[i] = z*i;
		}
	


	// perform interpolation
	for (i = 0; i < w; i++){
		for (j = 0; j < h; j++){

			x1 = x[i] + (1-REAL(sobelv)[i*h + j]/255)*rnorm(0,rand);
			y1 = y[j] + (1-REAL(sobelh)[i*h + j]/255)*rnorm(0,rand);
			
			REAL(res)[i*h + j] = InterpolatedValue(coeff, N_w, N_h, x1, y1, SplineDegree);
		 } 
	}
	
	UNPROTECT(P);
	
	PutRNGstate();
	
	return(res);
}

/************ 
Rotate a 2D-signal and interpolate with B-splines.

Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.

*************
M				input matrix
coeff		B-spline coefficient matrix
angle		rotation angle (rad)
degree	B-spline degree
*************/
SEXP rotate(SEXP M, SEXP coeff, SEXP angle, SEXP degree){
	
	SEXP res;
	
	int N_h,N_w,i,j,z,SplineDegree;
	int P = 0;
	
	double x1,y1,rad,tx,ty;
	double c,s;
	double center_x,center_y,shift_x,shift_y;
	
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}	
	
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	SplineDegree = INTEGER(degree)[0];
	rad = REAL(angle)[0];
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	c = cos(rad);
	s = sin(rad);
	
	// center coordinates
	center_x = (N_w-1)/2.0;
	center_y = (N_h-1)/2.0;
	shift_x = center_x - (c*center_x + s*center_y);
	shift_y = center_y - (c*center_y - s*center_x);

	/*** perform interpolation ***/
	
	for (i = 0; i < N_w; i++){
		tx = c*i + shift_x;
		ty = shift_y - s*i; 
		z = i*N_h;
		for (j = 0; j < N_h; j++){
			// target coordinates
			x1 = s*j + tx;
			y1 = c*j + ty;
			if ((x1 >= 0) && (x1 <= (N_w-1)) && (y1 >= 0) && (y1 <= (N_h-1)))
				REAL(res)[z+j] = InterpolatedValue(coeff, N_w, N_h, x1, y1, SplineDegree);
			else
				REAL(res)[z+j] = 255;
		 } 
	}
	
	UNPROTECT(P);
	
	return(res);
}



/************ 
Rotate a 2D-signal and interpolate with B-splines.

Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.

*************
M			input matrix
coeff		B-spline coefficient matrix
angle		rotation angle (rad)
degree		B-spline degree
*************/
SEXP rotate_2(SEXP M, SEXP coeff, SEXP angle, SEXP degree, SEXP r, 
							SEXP sobelh, SEXP sobelv){
	
	SEXP res;
	
	int N_h,N_w,i,j,z,SplineDegree;
	int P = 0;
	
	double x1,y1,rad,tx,ty,rand;
	double c,s;
	double center_x,center_y,shift_x,shift_y;
	
	rand = REAL(r)[0];
	
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}	
	
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	SplineDegree = INTEGER(degree)[0];
	rad = REAL(angle)[0];
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	c = cos(rad);
	s = sin(rad);
	
	// center coordinates
	center_x = (N_w-1)/2.0;
	center_y = (N_h-1)/2.0;
	shift_x = center_x - (c*center_x + s*center_y);
	shift_y = center_y - (c*center_y - s*center_x);

	/*** perform interpolation ***/
	GetRNGstate();
	
	for (i = 0; i < N_w; i++){
		tx = c*i + shift_x;
		ty = shift_y - s*i; 
		z = i*N_h;
		for (j = 0; j < N_h; j++){
			// target coordinates
			x1 = s*j + tx;
			y1 = c*j + ty;		
			x1 = x1 + (1-REAL(sobelv)[z + j]/255)*rnorm(0,rand);
			y1 = y1 + (1-REAL(sobelh)[z + j]/255)*rnorm(0,rand);
			
			if ((x1 >= 0) && (x1 <= (N_w-1)) && (y1 >= 0) && (y1 <= (N_h-1)))
				REAL(res)[z+j] = InterpolatedValue(coeff, N_w, N_h, x1, y1, SplineDegree);
			else
				REAL(res)[z+j] = 255;
		 } 
	}
	
	UNPROTECT(P);
	
	PutRNGstate();
	
	return(res);
}


/************ 
Rotate a 2D-signal and interpolate with B-splines.

Interpolation Revisited.
Philippe Th�venaz, Thierry Blu, Michael Unser.
IEEE Transactions on Medical Imaging 19(7), 739--758, 2000.

*************
M			input matrix
coeff		B-spline coefficient matrix
angle		rotation angle (rad)
degree		B-spline degree
*************/
SEXP rotate_3(SEXP M, SEXP coeff, SEXP angle, SEXP degree, SEXP r, 
							SEXP sobelh, SEXP sobelv, SEXP A){
	
	SEXP res;
	
	int N_h,N_w,i,j,z,SplineDegree;
	int P = 0;
	
	double x1,y1,rad,tx,ty,rand;
	double c,s,cn,sn;
	double center_x,center_y,shift_x,shift_y;
	double r1,r2,rx,ry;
	double a;
	
	rand = REAL(r)[0];
	
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}	
	
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	
	SplineDegree = INTEGER(degree)[0];
	rad = REAL(angle)[0];
	a = REAL(A)[0];
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	c = cos(rad);
	s = sin(rad);
	cn = cos(-rad);
	sn = sin(-rad);
	
	// center coordinates
	center_x = (N_w-1)/2.0;
	center_y = (N_h-1)/2.0;
	shift_x = center_x - (c*center_x + s*center_y);
	shift_y = center_y - (c*center_y - s*center_x);

	/*** perform interpolation ***/
	GetRNGstate();
	
	for (i = 0; i < N_w; i++){
		tx = c*i + shift_x;
		ty = shift_y - s*i; 
		z = i*N_h;
		for (j = 0; j < N_h; j++){
			// target coordinates
			x1 = s*j + tx;
			y1 = c*j + ty;		
			r1 = rnorm(0,rand);
			r2 = rnorm(0,rand);
			rx = cn*r1 + a*sn*r2;
			ry = a*cn*r2 - sn*r1;
			x1 = x1 + (1-REAL(sobelv)[z + j]/255)*rx;
			y1 = y1 + (1-REAL(sobelh)[z + j]/255)*ry;
			
			if ((x1 >= 0) && (x1 <= (N_w-1)) && (y1 >= 0) && (y1 <= (N_h-1)))
				REAL(res)[z+j] = InterpolatedValue(coeff, N_w, N_h, x1, y1, SplineDegree);
			else
				REAL(res)[z+j] = 255;
		 } 
	}
	
	UNPROTECT(P);
	
	PutRNGstate();
	
	return(res);
}



SEXP scale_phase(SEXP M, SEXP coeff, SEXP degree){

	SEXP res;
	
	int h, w, N_h, N_w, i, j, SplineDegree;
	int P = 0;
	
	double z,x1,y1;
	
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	h = N_h*2-1;
	w = N_w*2-1;
	
	SplineDegree = INTEGER(degree)[0];
	
	PROTECT(res = allocMatrix(REALSXP, h, w));
	P++;
	
	
	// interpolation positions in x and y direction
	double x[w], y[h];
	
		
	z = ((double)N_w-1)/(w-1);
	for (i = 0; i < w; i++){
		x[i] = z*i;
		}
	z = ((double)N_h-1)/(h-1);
	for (i = 0; i < h; i++){
		y[i] = z*i;
		}
	
	// perform interpolation
	for (i = 0; i < w; i++){
		for (j = 0; j < h; j++){
			
			x1 = x[i] + 0.25;
			y1 = y[j] + 0.25;
			
			REAL(res)[i*h + j] = InterpolatedValue(coeff, N_w, N_h, x1, y1, SplineDegree);
		 } 
	}
	
	UNPROTECT(P);
	return(res);
}


