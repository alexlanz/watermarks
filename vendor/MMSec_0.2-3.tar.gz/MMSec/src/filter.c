#include <R.h>
#include <Rmath.h>
#include <math.h>
#include <Rinternals.h>




/************ 
Compute the median filtered version of an (image) matrix 
*************
(only odd window-sizes are allowed)
*************/
SEXP median_filter(SEXP M, SEXP windowsize)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, l, mid;
	int P = 0;
	int *ind;
	double *col;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
	
	ww = w*w;
	mid = (ww-1)/2;
	l = (w-1)/2;
	
	// vector containing the current window
	col = (double *)R_alloc(w*w, sizeof(double));
	
	// indices of window elements
	ind = (int *)R_alloc(w*w, sizeof(int));
	for (i = 0; i < w; i++){
		z = i*w;
		zl = (i-l)*N_h;
		for (j = 0; j < w; j++){
			ind[z + j] = zl + (j-l);
		}
	}	
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/*** calculate median for each window ***/
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		z = i*N_h;
		for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			for (k = 0; k < ww; k++){ // windowing 
				col[k] = REAL(M)[z+j + ind[k]];
			}
		// sort values	
		R_qsort(col,1,ww); 
		// median
		REAL(res)[z + j] = col[mid];
		}
	}	
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	UNPROTECT(P);		
		
	return res;
}



/************ 
Compute the o-th order filtered version of an (image) matrix 
*************
(only odd window-sizes are allowed)
*************/
SEXP order_filter(SEXP M, SEXP windowsize, SEXP order)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, l, mid, o;
	int P = 0;
	int *ind;
	double *col;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	o = INTEGER(order)[0]-1;
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
		
	ww = w*w;
	mid = (ww-1)/2;
	l = (w-1)/2;
	
	if (o < 0 || o > ww)
		error("invalid order");

	
	// vector containing the current window
	col = (double *)R_alloc(w*w, sizeof(double));
	
	// indices of window elements
	ind = (int *)R_alloc(w*w, sizeof(int));
	for (i = 0; i < w; i++){
		z = i*w;
		zl = (i-l)*N_h;
		for (j = 0; j < w; j++){
			ind[z + j] = zl + (j-l);
		}
	}	
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	double *pres = &REAL(res)[0];
	double *pM = &REAL(M)[0];
	double *presA,*pMA,*colA;
	int *indA;
	
	/*** calculate max for each window ***/
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		pMA = pM+i*N_h+l;
		presA = pres+i*N_h+l;
		//z = i*N_h;
		for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			colA = col;
			indA = ind;
			for (k = 0; k < ww; k++){ // windowing 
				*(colA++) = *(pMA+(*indA));
				indA++;
				//col[k] = REAL(M)[z+j + ind[k]];
			}
			pMA++;
		// sort values	
		R_qsort(col,1,ww); 
		// max
		*(presA++) = col[o];
		//REAL(res)[z + j] = col[ww-1];
		}
	}	
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	UNPROTECT(P);		
		
	return res;
}


/************ 
Compute the o-th order filtered version of an (image) matrix 
*************
(only odd window-sizes are allowed)
*************/
SEXP max_filter(SEXP M, SEXP windowsize)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, l, mid;
	int P = 0;
	int *ind;
	double *col;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
		
	ww = w*w;
	mid = (ww-1)/2;
	l = (w-1)/2;
	
	// vector containing the current window
	col = (double *)R_alloc(w*w, sizeof(double));
	
	// indices of window elements
	ind = (int *)R_alloc(w*w, sizeof(int));
	for (i = 0; i < w; i++){
		z = i*w;
		zl = (i-l)*N_h;
		for (j = 0; j < w; j++){
			ind[z + j] = zl + (j-l);
		}
	}	
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	double *pres = &REAL(res)[0];
	double *pM = &REAL(M)[0];
	double *presA,*pMA,*colA;
	int *indA;
	
	
	/*** calculate max for each window ***/
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		pMA = pM+i*N_h+l;
		presA = pres+i*N_h+l;
		//z = i*N_h;
		for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			colA = col;
			indA = ind;
			*presA = *(pMA+(*indA));
			for (k = 1; k < ww; k++){ // windowing 
				indA++;
				if (*(pMA+(*indA)) > *presA) *presA = *(pMA+(*indA));
			}
			pMA++;presA++;
		// sort values	
		//R_qsort(col,1,ww); 
		// max
		//*(presA++) = col[o];
		//REAL(res)[z + j] = col[ww-1];
		}
	}	
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	UNPROTECT(P);		
		
	return res;
}



/************ 
Compute the minmax filtered version of an (image) matrix 
*************
(only odd window-sizes are allowed)
*************/
SEXP minmax_filter(SEXP M, SEXP windowsize, SEXP diff)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, l, mid, d;
	int P = 0;
	int *ind;
	double *col;
	double min, max, mean;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	d = INTEGER(diff)[0];
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
	
	ww = w*w;
	mid = (ww-1)/2;
	l = (w-1)/2;
	
	// vector containing the current window
	col = (double *)R_alloc(w*w, sizeof(double));
	
	// indices of window elements
	ind = (int *)R_alloc(w*w, sizeof(int));
	for (i = 0; i < w; i++){
		z = i*w;
		zl = (i-l)*N_h;
		for (j = 0; j < w; j++){
			ind[z + j] = zl + (j-l);
		}
	}	
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/*** calculate median for each window ***/
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		z = i*N_h;
		for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			mean = 0;
			for (k = 0; k < ww; k++){ // windowing 
				col[k] = REAL(M)[z+j + ind[k]];
				mean += col[k];
			}
		mean = mean/ww;	
		// sort values	
		R_qsort(col,1,ww); 
		// min
		min = col[d];
		max = col[ww-1-d];
		
		if ((REAL(M)[z+j] - min) > (max - REAL(M)[z+j]))
			REAL(res)[z + j] = max; 
		else
			REAL(res)[z + j] = min; 
		
		}
		
	}	
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	UNPROTECT(P);		
		
	return res;
}




/************ 
Compute the multi-stage median filtered version of an (image) matrix 
*************
G. R. Arce and R. E. Foster
Detail-Preserving Ranked-Order Based Filters for Image Processing
IEEE Transactions on Acoustics, Speech and Signal Processing 37 (1)
83�98, 1989

(only odd window-sizes are allowed)
*************/
SEXP m_median_filter(SEXP M, SEXP windowsize, SEXP bi)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, l, mid;
	int P = 0;
	int *indh, *indv, *indd_a, *indd_b;
	double *col;
	double mh_a, mh_b, mv_a, mv_b, md_a, md_b, md_c, md_d;
	double *medh, *medv, *medd_a, *medd_b, *med1, *med2, *med;
	int bid;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	bid = INTEGER(bi)[0];
	
	
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
	
	ww = w*w;
	mid = (ww-1)/2;
	l = (w-1)/2;
	
	// vector containing the current window
	col = (double *)R_alloc(w*w, sizeof(double));
	
	// indices of window elements
	if (bid) { // bidirectional
		indh = (int *)R_alloc(2*w-1, sizeof(int));
		indd_a = (int *)R_alloc(2*w-1, sizeof(int));
		medh = (double *)R_alloc(2*w-1, sizeof(double));
		medd_a = (double *)R_alloc(2*w-1, sizeof(double));
	}
	else { // unidirectional
		indh = (int *)R_alloc(w, sizeof(int));
		indv = (int *)R_alloc(w, sizeof(int));
		indd_a = (int *)R_alloc(w, sizeof(int));
		indd_b = (int *)R_alloc(w, sizeof(int));
		medh = (double *)R_alloc(w, sizeof(double));
		medv = (double *)R_alloc(w, sizeof(double));
		medd_a = (double *)R_alloc(w, sizeof(double));
		medd_b = (double *)R_alloc(w, sizeof(double));
	}
	
	med1 = (double *)R_alloc(3, sizeof(double));
	med2 = (double *)R_alloc(3, sizeof(double));
	
	med = (double *)R_alloc(3, sizeof(double));
	
	for (i = 0; i < w; i++){
		zl = (i-l)*N_h;
		
		if (bid){ // bidirectional
			
			indh[i] = zl;							// horizontal
			indd_a[i] = indh[i] + i-(l+1);			// diagonal a
			 
			if (i < l){
				indh[i+w] = i - (l+1);				// vertical
				indd_a[i+w] = indh[i] - i+(l-1);	// diagonal b
				}
			if (i > l){
				indh[i+w-1] = i - (l+1);			// vertical
				indd_a[i+w-1] = indh[i] - i+(l-1);	// diagonal b
				}
				
		}
		else{ // unidirectional 
			
			indh[i] = zl;							// horizontal
			indv[i] = i - (l+1);					// vertical
			indd_a[i] = indh[i] + indv[i];			// diagonal a
			indd_b[i] = indh[i] - indv[i];			// diagonal b
		}
	}
	

	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	GetRNGstate();
	
	/*** calculate median for each window ***/
	
	if (bid){// bidrectional
		for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
			z = i*N_h;
			for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			
				for (k = 0; k < 2*w-1; k++){ // windowing 
					medh[k] = REAL(M)[z+j + indh[k]];
					medd_a[k] = REAL(M)[z+j + indd_a[k]];
				}
			
				// stage 1
				R_qsort(medh,1,2*w-1);
				R_qsort(medd_a,1,2*w-1);
			
				med1[0] = medh[w-1];
				med1[1] = medd_a[w-1];
				med1[2] = REAL(M)[z+j];
			
				//stage 2
				R_qsort(med1,1,3);

				REAL(res)[z + j] = med1[1];
			}
		}		
	
	}
	
	else{ // unidirectional
		for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
			z = i*N_h;
			for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			
				for (k = 0; k < w; k++){ // windowing 
					medh[k] = REAL(M)[z+j + indh[k]];
					medv[k] = REAL(M)[z+j + indv[k]];
					medd_a[k] = REAL(M)[z+j + indd_a[k]];
					medd_b[k] = REAL(M)[z+j + indd_b[k]];
				}
			
				// stage 1
				R_qsort(medh,1,w);
				R_qsort(medv,1,w);
				R_qsort(medd_a,1,w);
				R_qsort(medd_b,1,w);
			
				med1[0] = medh[l];
				med1[1] = medv[l];
				med1[2] = REAL(M)[z+j];
			
				med2[0] = medd_a[l];
				med2[1] = medd_a[l];
				med2[2] = REAL(M)[z+j];
			
				//stage 2
				R_qsort(med1,1,3);
				R_qsort(med2,1,3);
			
				med[0] = med1[1];
				med[1] = med2[1];
				med[2] = REAL(M)[z+j];
				
				//stage 3
				R_qsort(med,1,3);
				
				REAL(res)[z + j] = med[1];
			}
		}	
	}
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	PutRNGstate();
	
	UNPROTECT(P);		
		
	return res;
}




/************ 
Compute the binomial filtered version of an (image) matrix 
*************
(only odd window-sizes are allowed)
*************/
SEXP binomial_filter2(SEXP M, SEXP windowsize)	{
	
	SEXP res;
	int i, j, k, N_h, N_h1, N_w, N_w1, z, z1, zl, w, l, c;
	int P = 0;
	double *temp, *temp1, f;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
	

	l = (w-1)/2;
		
	temp  = (double *)R_alloc(N_h*N_w, sizeof(double));
	temp1 = (double *)R_alloc((N_h*N_w)-1, sizeof(double));
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	for (i = 0; i < N_w; i++){ // iterate matrix column wise
		z = i*N_h;
		for (j = 0; j < N_h; j++){ // iterate matrix row wise
			temp[z+j] = REAL(M)[z+j];
		}
	}
	
	/*** columns ***/
	
	for (c = 0; c < w-1; c++){ /* c is counter representing the current stage 
							    in the filtering network */
		k = 0;
		N_h1 = N_h - (c+1);
		if (c % 2 == 0) {
			for (i = 0; i < N_w; i++){ // iterate matrix column wise
				z = i*(N_h-c);
				for (j = 0; j < N_h1; j++){ // iterate matrix row wise
					temp1[k] = temp[z+j] + temp[z+j+1];
					k++;
				}
			}
		}
		else{
			for (i = 0; i < N_w; i++){ // iterate matrix column wise
				z = i*(N_h-c);
				for (j = 0; j < N_h1; j++){ // iterate matrix row wise
					temp[k] = temp1[z+j] + temp1[z+j+1];
					k++;
				}
			}
		}
	}

	/*** rows ***/
	
	N_h1 = N_h - 2*l;
	for (c = 0; c < w-1; c++){ /* c is counter representing the current stage 
							    in the filtering network */
		k = 0;
		N_w1 = N_w - (c+1);
		if (c % 2 == 0) {
			for (i = 0; i < N_w1; i++){ // iterate matrix column wise
				z  = i*N_h1;
				z1 = z + N_h1;
				for (j = 0; j < (N_h-2*l); j++){ // iterate matrix row wise
					temp1[k] = temp[z+j] + temp[z1+j];
					k++;
				}
			}
		}
		else{
			for (i = 0; i < N_w1; i++){ // iterate matrix column wise
				z  = i*N_h1;
				z1 = z + N_h1;
				for (j = 0; j < (N_h-2*l); j++){ // iterate matrix row wise
					temp[k] = temp1[z+j] + temp1[z1+j];
					k++;
				}
			}
		}
	}
	
	
	/*** resulting filtered matrix ***/	
	
	k = 0;
	f = pow(2,2*w-2);
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		z = i*N_h;
		for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			REAL(res)[z+j] = temp[k]/f;
			k++;
		}
	}
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	UNPROTECT(P);		
		
	return res;
}



/************ 
Compute the average filtered version of an (image) matrix 
*************
(only odd window-sizes are allowed)
*************/
SEXP average_filter(SEXP M, SEXP windowsize)	{
	
	SEXP res;
	
	int N_h, N_w, w, ww, l, i, j, k, z, zl;
	int *ind, *ind_t, *ind_b;
	int P = 0;
	
	double sum, sum_t, sum_b;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	ww = w*w;
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
	

	l = (w-1)/2;
	
	// indices of window elements
	ind = (int *)R_alloc(w*w, sizeof(int));
	ind_t = (int *)R_alloc(w, sizeof(int));
	ind_b = (int *)R_alloc(w, sizeof(int));
	for (i = 0; i < w; i++){
		z = i*w;
		zl = (i-l)*N_h;
		for (j = 0; j < w; j++){
			ind[z + j] = zl + (j-l);
			if (j == 0){
				ind_t[i] = ind[z+j];
				//Rprintf("%d  ",ind_t[i]); 
				}
				//Rprintf("\n");
			if (j == (w-1)){
				ind_b[i] = ind[z+j];
				//Rprintf("%d  ",ind_b[i]); 
				}
		}
	}	
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/*** calculate average filtered version for each window ***/
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		z = i*N_h;
		sum = 0;
		sum_t = 0;
		for (k = 0; k < ww; k++){ // windowing 
				sum += REAL(M)[z+l + ind[k]];
			}
		for (k = 0; k < w; k++){ // windowing 
				sum_t += REAL(M)[z+l + ind_t[k]];
			}
		
		REAL(res)[z + l] = sum/ww;
		
		for (j = l+1; j < (N_h-l); j++){ // iterate matrix row wise
			
			sum_b = 0;
			for (k = 0; k < w; k++){ // windowing 
				sum_b += REAL(M)[z+j + ind_b[k]];
			}
			
			sum = sum + sum_b - sum_t;
	
			sum_t = 0;
			for (k = 0; k < w; k++){ // windowing 
				sum_t += REAL(M)[z+j + ind_t[k]];
			}
			
			REAL(res)[z + j] = sum/ww;

		}
	}

	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	UNPROTECT(P);
	
	return res;
}



/************ 
Compute the sobel filtered version of an (image) matrix 
*************
(only odd window-sizes are allowed)
*************/
SEXP sobel_filter(SEXP M, SEXP dir)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, l, mid,d;
	int P = 0;
	int *ind;
	double *col;
	double x;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	//if (!isInteger(windowsize))
	//	error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	d = INTEGER(dir)[0];
	w = 3;
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	ww = w*w;
	mid = (ww-1)/2;
	l = (w-1)/2;
	
	// vector containing the current window
	col = (double *)R_alloc(w*w, sizeof(double));
	
	// indices of window elements
	ind = (int *)R_alloc(w*w, sizeof(int));
	for (i = 0; i < w; i++){
		z = i*w;
		zl = (i-l)*N_h;
		for (j = 0; j < w; j++){
			ind[z + j] = zl + (j-l);
		}
	}	
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/*** calculate binomial filtered version for each window ***/
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		z = i*N_h;
		for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			for (k = 0; k < ww; k++){ // windowing 
				col[k] = REAL(M)[z+j + ind[k]];
			}
		
		// sobel filtering
		if (d == 1)
		{ // vertical
			x =	-   col[0]
				- 2*col[1]
				-   col[2]
				+   col[6]
				+ 2*col[7]
				+   col[8];
		}
		else 
		{ // horizontal
			x =	-   col[2]
				- 2*col[5]
				-   col[8]
				+   col[0]
				+ 2*col[3]
				+   col[6];
		}
		x = fabs(x);
		if (x > 255) x = 255;
		REAL(res)[z + j] = 	x;
			
		}
	}	
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = 0;
			REAL(res)[zl + j] = 0;
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = 0;
			REAL(res)[z + N_h-1-k] = 0;
		}
	}
	
	UNPROTECT(P);		
		
	return res;
}


/************ 
Apply a rectangular filter of arbitrary size and coefficients
*************
(only odd window-sizes are allowed)
*************/
SEXP gen_filter(SEXP M, SEXP windowsize, SEXP coeff)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, w_h, w_w,l_h, l_w;
	int P = 0;	
	int *ind;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
			
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w_h = INTEGER(windowsize)[0]; // horizontal window size
	w_w = INTEGER(windowsize)[1]; // vertical window size
	l_h = (w_h-1)/2; 
	l_w = (w_w-1)/2;
	ww = w_h*w_w; // absolute window size
	
	if (length(coeff) != ww)
		error("specified window size does not match the dimensions of the coefficient matrix/vector");	
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (isInteger(coeff)){
		PROTECT(coeff = coerceVector(coeff, REALSXP));
		P++;
		}
	
	// relative indices of window elements
	k = 0;
	ind = (int *)R_alloc(ww, sizeof(int));
	for (i = 0; i < w_w; i++){
		zl = (i-l_w)*N_h; // column offset
		for (j = 0; j < w_h; j++)
			ind[k++] = zl + (j-l_h); // column offset + row offset
	}	
	

	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/*** filtering ***/
	
	double *pRes, *pM;
	double *pResA, *pMA;
	double *pCoeff;
	int *pInd;
	
	pRes = &REAL(res)[l_h+l_w*N_h];
	pM = &REAL(M)[l_h+l_w*N_h];
	pResA = pRes;
	pMA = pM;
	
	for (i = l_w; i < (N_w-l_w); i++){ // iterate matrix column wise
		pResA = pRes;
		pMA = pM;
		for (j = l_h; j < (N_h-l_h); j++){ // iterate matrix row wise
			*pResA = 0;
			pCoeff = &REAL(coeff)[0];
			pInd = ind;
			for (k = 0; k < ww; k++) // windowing 
				*pResA += *(pCoeff++)*(*(pMA+*(pInd++)));
			pResA++;pMA++;
		}
		pRes += N_h;pM += N_h;
	}	
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	pRes = &REAL(res)[0];
	pM = &REAL(M)[0];
	memcpy(pRes,pM,l_w*N_h*sizeof(double));
	pRes = &REAL(res)[(N_w-l_w)*N_h];
	pM = &REAL(M)[(N_w-l_w)*N_h];
	memcpy(pRes,pM,l_w*N_h*sizeof(double));
	
	
	// fill bordering rows
	pRes = &REAL(res)[0];
	pM = &REAL(M)[0];
	double *pRes1 = pRes+N_h-l_h;
	double *pM1 = pM+N_h-l_h;
	double *pRes1A, *pM1A;
	for (i = 0; i < (N_w); i++){
		pResA = pRes;
		pRes1A = pRes1;
		pMA = pM;
		pM1A = pM1;
		for (k = 0; k < l_h; k++){
			*(pResA++) = *(pMA++);
			*(pRes1A++) = *(pM1A++);
		}
		pRes += N_h;pRes1 += N_h;
		pM += N_h;pM1 += N_h;
	}
	
	UNPROTECT(P);		

	return res;
}



/************ 
Apply a rectangular filter of arbitrary size and coefficients
*************
(only odd window-sizes are allowed)
*************/

SEXP gen_filter1(SEXP M, SEXP windowsize, SEXP coeff)	{
	
	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, w_h, w_w,l_h, l_w;
	int P = 0;	
	int *ind;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
			
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w_h = INTEGER(windowsize)[0]; // horizontal window size
	w_w = INTEGER(windowsize)[1]; // vertical window size
	l_h = (w_h-1)/2; 
	l_w = (w_w-1)/2;
	ww = w_h*w_w; // absolute window size
	
	if (length(coeff) != ww)
		error("specified window size does not match the dimensions of the coefficient matrix/vector");	
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (isInteger(coeff)){
		PROTECT(coeff = coerceVector(coeff, REALSXP));
		P++;
		}
	
	// relative indices of window elements
	k = 0;
	ind = (int *)R_alloc(ww, sizeof(int));
	for (i = 0; i < w_w; i++){
		zl = (i-l_w)*N_h; // column offset
		for (j = 0; j < w_h; j++)
			ind[k++] = zl + (j-l_h); // column offset + row offset
	}	
	

	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/*** filtering ***/
	
	for (i = l_w; i < (N_w-l_w); i++){ // iterate matrix column wise
		z = i*N_h;
		for (j = l_h; j < (N_h-l_h); j++){ // iterate matrix row wise
			REAL(res)[z+j] = 0;
			for (k = 0; k < ww; k++){ // windowing 
				REAL(res)[z+j] += REAL(coeff)[k]*REAL(M)[z+j + ind[k]];
			}
		}
	}	
	
	/*** fill filtered image borders with original values ***/

	// fill bordering columns
	for (k = 0; k < l_w; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = REAL(M)[z + j];
			REAL(res)[zl + j] = REAL(M)[zl + j];
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l_h; k++){
			REAL(res)[z + k] = REAL(M)[z + k];
			REAL(res)[z + N_h-1-k] = REAL(M)[z + N_h-1-k];
		}
	}
	
	UNPROTECT(P);		

	return res;
}



SEXP local_variance(SEXP M, SEXP windowsize) {

	SEXP res;
	int i, j, k, N_h, N_w, z, zl, w, ww, l, mid;
	int P = 0;
	int *ind;
	double *col, mean, var, b;
	
	/*** check parameters ***/
	
	if (!isMatrix(M))
		error("M must be a matrix");
		
	if (!isInteger(windowsize))
		error("window size must be integer value");
	
	// matrix and window size		
	N_h = INTEGER(getAttrib(M,R_DimSymbol))[0];
	N_w = INTEGER(getAttrib(M,R_DimSymbol))[1];
	w = INTEGER(windowsize)[0];
	
	if (isInteger(M)){
		PROTECT(M = coerceVector(M, REALSXP));
		P++;
		}
	
	if (w > N_h || w > N_w)
		error("window must not be bigger than (image) matrix");
	
	if (w%2 == 0)
		error("only odd window size allowed");
	
	ww = w*w;
	mid = (ww-1)/2;
	l = (w-1)/2;
	
	// vector containing the current window
	col = (double *)R_alloc(w*w, sizeof(double));
	
	// indices of window elements
	ind = (int *)R_alloc(w*w, sizeof(int));
	for (i = 0; i < w; i++){
		z = i*w;
		zl = (i-l)*N_h;
		for (j = 0; j < w; j++){
			ind[z + j] = zl + (j-l);
		}
	}	
	
	PROTECT(res = allocMatrix(REALSXP, N_h, N_w));
	P++;
	
	/*** calculate filtered (image) matrix ***/
	
	for (i = l; i < (N_w-l); i++){ // iterate matrix column wise
		z = i*N_h;
		for (j = l; j < (N_h-l); j++){ // iterate matrix row wise
			mean = 0;
			var = 0;
			for (k = 0; k < ww; k++){ // windowing 
				col[k] = REAL(M)[z+j + ind[k]];
				mean += col[k];
			}
			mean = mean/ww;
			
			for (k = 0; k < ww; k++){
				var += pow(col[k]-mean,2);
			}
			var = var/(ww-1);
			REAL(res)[z+j] = var;
		}
	}
	
	/*** fill filtered image borders with original values ***/
	
	// fill bordering columns
	for (k = 0; k < l; k++){
		z = k*N_h;
		zl = (N_w-1-k)*N_h;
		for (j = 0; j < (N_h); j++){
			REAL(res)[z + j] = 0;
			REAL(res)[zl + j] = 0;
		}
	}
	
	// fill bordering rows
	for (i = 0; i < (N_w); i++){
		z = i*N_h;
		for (k = 0; k < l; k++){
			REAL(res)[z + k] = 0;
			REAL(res)[z + N_h-1-k] = 0;
		}
	}
	
	UNPROTECT(P);		
	return res;
}
