//  stegttools.c - This file contains tool routines for the R package "steganal" 
//
//  (c) 2004, 2005 Technische Universitaet Dresden, Germany
//  
//  Authors:	Nils Moh, Rainer Boehme


#define USE_RINTERNALS 1

#include <R.h>
#include <Rinternals.h>
#include "stegtools.h"

SEXP getListElement(SEXP list , char * str)
{
SEXP elmt=NULL,names= getAttrib(list,R_NamesSymbol);
int i;
for(i=0;i<length(list);i++)
 if(strcmp(CHAR(STRING_ELT(names,i)),str)==0)
  {
  elmt=VECTOR_ELT(list,i);
  break;
  }
return(elmt);

}


void check_overwrite(char * fname,SEXP overwrite)
{ FILE * f;

  if (f = fopen(fname, "rb")) {
    fclose(f);
    if (!asLogical(overwrite))
      error("%s already exists. Use overwrite=TRUE to replace it.",fname);
  }
}
