/* 
 * Copyright (c) 2004 Technische Universitaet Dresden
 * Author Benjamin Scholz
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 *  This code is inspired by the code from bmptopnm.c
 *
 *  Copyright (C) 1992 by David W. Sanderson.
 *
 *  Permission to use, copy, modify, and distribute this software and its
 *  documentation for any purpose and without fee is hereby granted,
 *  provided that the above copyright notice appear in all copies and
 *  that both that copyright notice and this permission notice appear
 *  in supporting documentation.  This software is provided "as is"
 *  without express or implied warranty.
 *
 */

#include <math.h>
#include <R.h>
#include <Rinternals.h>
#include "labels.h"
#include "getter.h"
#include "stegtools.h"

#define BMP_MAX_PAL_COLORS 256

struct
{ unsigned char * data;
  
  int dx;
  int dy;
  int grey;
  int palette;
  
  struct
  { int numcol;
    int r[BMP_MAX_PAL_COLORS],
	g[BMP_MAX_PAL_COLORS],
	b[BMP_MAX_PAL_COLORS];
  } pal;

} bmp_global;

int bmp_do_read(const char * fname)
{ 
	FILE * fp;

	// Header Info
	int infoHeaderSize,bitPerPixel;
	
	if (!(fp = fopen(fname, "rb"))) 
		error("unable to open file %s",fname);
 
	// read the Fileheader
	if ((getByte(fp) != 'B') ||(getByte(fp) != 'M'))
		error("%s is not a BMP file", fname);
	
	getLong(fp); // Filesize

	if (getLong(fp) != 0) 
		error("%s is not a BMP file", fname);

	getLong(fp); // Offset to the data
	
	bmp_global.pal.numcol = 0;
	
	// read the Infoheader
	infoHeaderSize = getLong(fp); // Infoheader size
	switch (infoHeaderSize) {
	case 12:
	// OS/2 BMP
		bmp_global.dx = getShort(fp); // width
		bmp_global.dy = getShort(fp); // depth
		getShort(fp); // biplanes (has to be 1)
		bitPerPixel= getShort(fp); // bit per Pixel
		break;
	
	case 40:
	// Windows Bitmap
		bmp_global.dx = getLong(fp); // width
		bmp_global.dy = getLong(fp); // depth
		getShort(fp); // biplanes (has to be 1)
		bitPerPixel = getShort(fp); // bit per Pixel
	
		if (getLong(fp) != 0 ) // compression type (0=none, 1=RLE...)
			error("Bitmap is compressed, can't handle compressed Bitmaps!");

		getLong(fp); // ImageSize or zero
		getLong(fp); // XpixelsPerM
		getLong(fp); // YpixelsPerM 
		bmp_global.pal.numcol = getLong(fp); // ColorsUsed
		getLong(fp); // colors important
		break;
	
	default:
		error("unknown type of Bitmap - Neither a Windows nor OS/2 Bitmap!");
	}

	if (bitPerPixel == 1) bmp_global.grey = 1;
	else bmp_global.grey = 0;

	// read the colormap
	if (bmp_global.pal.numcol) {
		int i;
		bmp_global.palette = 1;
		for (i = 0; i < bmp_global.pal.numcol; ++i) {
			bmp_global.pal.b[i] = getByte(fp) & 0xFF;
			bmp_global.pal.g[i] = getByte(fp) & 0xFF;
			bmp_global.pal.r[i] = getByte(fp) & 0xFF;
			getByte(fp); // one extra Byte
			//printf("%d ",bmp_global.pal.b[i]);
		}
	}
	else 
		bmp_global.palette = 0;
	

	// read the data
	{
		int row;
	
		if (bitPerPixel == 24)
			bmp_global.data = (char *) malloc(bmp_global.dx*bmp_global.dy*3);
		else
			bmp_global.data = (char *) malloc(bmp_global.dx*bmp_global.dy);
		
		 // The picture is stored bottom line first, top line last
		
		for (row = bmp_global.dy - 1; row >= 0; --row) {
			unsigned int bytesRead, x;
			char * currentLine;
			bytesRead = 0;
	
			// Read one line
			if (bitPerPixel == 24)
				currentLine = &(bmp_global.data[row*bmp_global.dx*3]);
			else
				currentLine = &(bmp_global.data[row*bmp_global.dx]);
			
			for (x = 0; x < bmp_global.dx; ++x) {
				switch(bitPerPixel){
				case 1:
				case 8:
					// colormapped
					currentLine[x] = getByte(fp);
					//printf("%X \n", currentLine[x]);
					++bytesRead;
					break;
				case 4:
					// colormapped but 1 Byte for 2 Pixel
					{ 
						int a;
						a = getByte(fp);
						currentLine[x++] = (a & 0xF0)>>4;
						currentLine[x] = 	(a & 0x0F);			
						++bytesRead;
					}
					break;
				case 24:
					// It's truecolor
					currentLine[x*3+2]= getByte(fp); // B
					currentLine[x*3+1]= getByte(fp); // G
					currentLine[x*3]  = getByte(fp); // R
					bytesRead+=3;
				}
				
			}
			
		
			/* Make sure we read a multiple of 4 bytes. */
			while (bytesRead % 4) {
				getByte(fp);
				++bytesRead;
			}
		}
		//{int x;for(x=0; x< bmp_global.dx*bmp_global.dy;++x)	printf("%d ",bmp_global.data[x]);}
	}
}


// BMP Import Functions

SEXP bmp_read_rgb(SEXP file)
{ const char * filename = CHAR(PROTECT(asChar(file)));
  SEXP ans, names, class, palette, pnames; 
  SEXP red, green, blue, grey, map;
  int P = 1;
  
  int dx, dy, x, y, i, k, slot;
  unsigned char * p; 
  
  bmp_do_read(filename);

  dx = bmp_global.dx; 
  dy = bmp_global.dy;
  p  = bmp_global.data;
  
  PROTECT(class = allocVector(STRSXP,1)); P++;
  
  // store pixel data in matrices
  
  if (bmp_global.palette)
  {
    // class "indexmap"
    
    SET_STRING_ELT(class, 0, mkChar(LABEL_INDEXMAP)); 
     
    PROTECT(map = allocMatrix(INTSXP, dy, dx)); P++;
    for (y=0;y<dy;y++)
      for (x=0;x<dx;x++)
       INTEGER(map)[dy*x+y] = *(p++)+1;
		//printf("%d \n",*(p++)+1);
    // create palette
    
    PROTECT(palette = allocVector(VECSXP,3)); P++;

    PROTECT(red=   allocVector(REALSXP, bmp_global.pal.numcol)); P++;
    PROTECT(green= allocVector(REALSXP, bmp_global.pal.numcol)); P++;
    PROTECT(blue=  allocVector(REALSXP, bmp_global.pal.numcol)); P++;

    for (y=0;y<bmp_global.pal.numcol;y++)
    {
      REAL(red)[y]   = ((double) bmp_global.pal.r[y])/255;
      REAL(green)[y] = ((double) bmp_global.pal.g[y])/255;
      REAL(blue)[y]  = ((double) bmp_global.pal.b[y])/255;
    }
        
    SET_VECTOR_ELT(palette, 0, red);
    SET_VECTOR_ELT(palette, 1, green);
    SET_VECTOR_ELT(palette, 2, blue);
    
    // define names for palette sub-structure
  
    PROTECT(pnames = allocVector(VECSXP,3)); P++;
    
    SET_VECTOR_ELT(pnames, 0, mkChar(LABEL_RED));
    SET_VECTOR_ELT(pnames, 1, mkChar(LABEL_GREEN));
    SET_VECTOR_ELT(pnames, 2, mkChar(LABEL_BLUE));

    setAttrib(palette, R_NamesSymbol, pnames);
    
    // create list for indexmap components
     
    PROTECT(ans= allocVector(VECSXP,3)); P++;

    SET_VECTOR_ELT(ans, 0, map);
    SET_VECTOR_ELT(ans, 1, palette);
    SET_VECTOR_ELT(ans, 2, file);

    // add element names
     
    PROTECT(names = allocVector(VECSXP,3)); P++;

    SET_VECTOR_ELT(names, 0, mkChar(LABEL_MAP));
    SET_VECTOR_ELT(names, 1, mkChar(LABEL_PALETTE));
    SET_VECTOR_ELT(names, 2, mkChar(LABEL_NAME));
  }
  
  else {  // no index map, hence either greymap or rgbmap
	
  if (bmp_global.grey)
  {
    // class "greymap"
    
    SET_STRING_ELT(class, 0, mkChar(LABEL_GREYMAP));
    
    PROTECT(grey = allocMatrix(REALSXP, dy, dx)); P++;
    for (y=0;y<dy;y++)
      for (x=0;x<dx;x++)
	REAL(grey)[dy*x+y] = ((double)*(p++))/255;
    
    // create list for grey matrix
    
    PROTECT(ans = allocVector(VECSXP,2)); P++;
    
    SET_VECTOR_ELT(ans, 0, grey);
    SET_VECTOR_ELT(ans, 1, file);
  
    // add element names
  
    PROTECT(names = allocVector(VECSXP,2)); P++;
  
    SET_VECTOR_ELT(names, 0, mkChar(LABEL_GREY));
    SET_VECTOR_ELT(names, 1, mkChar(LABEL_NAME));
  }
  else
  {
    // class "rgbmap"
    
    SET_STRING_ELT(class, 0, mkChar(LABEL_RGBMAP));
    
    PROTECT(red   = allocMatrix(REALSXP, dy, dx)); P++;
    PROTECT(green = allocMatrix(REALSXP, dy, dx)); P++;
    PROTECT(blue  = allocMatrix(REALSXP, dy, dx)); P++;
  
    for (y=0;y<dy;y++)
      for(x=0;x<dx;x++) {
	REAL(red)[dy*x+y]   = ((double)*(p++))/255;
	REAL(green)[dy*x+y] = ((double)*(p++))/255;
	REAL(blue)[dy*x+y]  = ((double)*(p++))/255;
      }
  
    // create list of red, green and blue matrices
  
    PROTECT(ans = allocVector(VECSXP,4)); P++;
  
    SET_VECTOR_ELT(ans, 0, red);
    SET_VECTOR_ELT(ans, 1, green);
    SET_VECTOR_ELT(ans, 2, blue);
    SET_VECTOR_ELT(ans, 3, file);
  
    // add element names
  
    PROTECT(names = allocVector(VECSXP,4)); P++;
  
    SET_VECTOR_ELT(names, 0, mkChar(LABEL_RED));
    SET_VECTOR_ELT(names, 1, mkChar(LABEL_GREEN));
    SET_VECTOR_ELT(names, 2, mkChar(LABEL_BLUE));	
    
    SET_VECTOR_ELT(names, 3, mkChar(LABEL_NAME));
  }
  } 
    
  setAttrib(ans, R_NamesSymbol, names);

  // set class 

  classgets(ans,class);

  UNPROTECT(P);
  return ans;
}

SEXP bmp_write_rgb(SEXP map, SEXP file, SEXP overwrite, SEXP index)
{
	char * filename = CHAR(PROTECT(asChar(file)));
	FILE * f;
	SEXP red, green, blue, palette, indexmap;
	int bitPerPixel, y;


	// check call parameters
 
	if (isNull(map)) error("%s or %s required",LABEL_RGBMAP,LABEL_GREYMAP);
	if (isNull(file)) error("filename required");
	

	// try opening output file

	check_overwrite(filename,overwrite);
  
	if (!(f = fopen(filename, "wb"))) 
		error("unable to create file %s",filename);


	// read the File Properties
	
	if (asLogical(index)) {
		//printf("index\n");
		palette = getListElement(map,LABEL_PALETTE);

		red   = getListElement(palette,LABEL_RED);
		green = getListElement(palette,LABEL_GREEN);
		blue  = getListElement(palette,LABEL_BLUE);
		
		indexmap = getListElement(map,LABEL_MAP);
	
		bmp_global.pal.numcol = length(red);
		bmp_global.dx = INTEGER(getAttrib(indexmap,R_DimSymbol))[1];
		bmp_global.dy = INTEGER(getAttrib(indexmap,R_DimSymbol))[0];

		if (bmp_global.pal.numcol <= 16)
			bitPerPixel = 4;
		else
			bitPerPixel = 8;
	
	} else {
		//printf("rgb\n");
		bitPerPixel = 24;
		bmp_global.pal.numcol = 0;
	
		red	= getListElement(map,LABEL_RED);
		green = getListElement(map,LABEL_GREEN);
		blue  = getListElement(map,LABEL_BLUE);

		bmp_global.dx = INTEGER(getAttrib(red,R_DimSymbol))[1];
		bmp_global.dy = INTEGER(getAttrib(red,R_DimSymbol))[0];
	
	}
	

	// write the Fileheader
	
	putByte('B',f);
	putByte('M',f);

	putLong(0xFFFFFFFF,f); // Filesize, will be set at the end
	
	putLong(0,f); // 4x 00 reserved

	putLong(0xFFFFFFFF,f); // Offset to the data, will be set later


	// write the Infoheader
	
	putLong(40,f); // Infoheader size

	putLong(bmp_global.dx, f); // width
	putLong(bmp_global.dy, f); // depth
	putShort(1, f); // biplanes (has to be 1)

	putShort(bitPerPixel, f); // bit per Pixel

	putLong(0, f); // compression type (0=none, 1=RLE...)
	
	putLong(0, f); // ImageSize or zero

	putLong(0, f); // XpixelsPerM
	putLong(0, f); // YpixelsPerM 
	putLong(bmp_global.pal.numcol, f); // ColorsUsed
	putLong(0, f); // colors important

	// write the colormap
	if (bmp_global.pal.numcol) {
		int pos;
		for (pos = 0; pos < bmp_global.pal.numcol; ++pos) {
			putByte((unsigned char)(0.5+255*REAL(blue)[pos]), f); // Blue
			putByte((unsigned char)(0.5+255*REAL(green)[pos]), f); // Green
			putByte((unsigned char)(0.5+255*REAL(red)[pos]), f); // Red
			putByte(0, f); // one extra Byte
		}
	}

	// write the data
	// write the offset
	{
		long offset = ftell(f);
		fseek(f,10,SEEK_SET);
		putLong(offset, f);
		fseek(f,offset, SEEK_SET);
	}
	for (y=1;y<=bmp_global.dy; ++y) {
		int x;
		int bytesWritten = 0;
		switch (bitPerPixel) {
		case 1:
		case 8:
				for (x=1;x<=bmp_global.dx;++x) {
					putByte((INTEGER(indexmap)[bmp_global.dy*x-y]-1),f);
					++bytesWritten;
				}
			break;
		case 4:
			// colormapped but 1 Byte for 2 Pixel
			for (x=1;x<=bmp_global.dx;++x) {
				int value = (INTEGER(indexmap)[bmp_global.dy*x-y]-1)<<4;
				++x;
				value += (INTEGER(indexmap)[bmp_global.dy*x-y]-1);
				putByte(value,f);
				++bytesWritten;
			}
			break;
		case 24:
			// Truecolor 24 bit per Pixel
			for (x=1;x<=bmp_global.dx;++x) {
				int pos = bmp_global.dy*x-y;
				putByte((unsigned char)(0.5+255*REAL(blue)[pos]),f);
				putByte((unsigned char)(0.5+255*REAL(green)[pos]),f);
				putByte((unsigned char)(0.5+255*REAL(red)[pos]),f);
				bytesWritten += 3;
			}
		}

		// Make sure we write a multiple of 4 bytes. 
		while (bytesWritten % 4) {
			putByte(0, f);
			++bytesWritten;
		}
	}

	// write the Filesize
	{
		long size = ftell(f);
		fseek(f,2,SEEK_SET);
		putLong(size, f);
	}

	fclose(f);
	UNPROTECT(1);
	return file;
}
