//avoid having 3 versions of this function .. by Nils Moh
//renamed to orginal Name and deleted the other versions .. by Ben

SEXP getListElement (SEXP list,char * str);

void check_overwrite (char * fname, SEXP overwrite);
